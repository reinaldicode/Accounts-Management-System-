<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\SystemSelectionController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\SystemController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UserSystemAccessController;
use App\Http\Controllers\AuditController;
use App\Http\Controllers\GroupController;

/*
|--------------------------------------------------------------------------
| Web Routes - UMS
|--------------------------------------------------------------------------
*/

// Route ini khusus untuk mengecek apakah Extension LDAP sudah aktif di server.
Route::get('/cek-ldap', function () {
    if (function_exists('ldap_connect')) {
        return "✅ LDAP Extension AKTIF! Siap digunakan.";
    } else {
        return "❌ LDAP Extension BELUM AKTIF. Silakan buka php.ini, cari ';extension=ldap', hapus titik komanya, lalu restart web server.";
    }
});

// ============================================
// PUBLIC ROUTES
// ============================================
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.post');
});

Route::get('/logout', [AuthController::class, 'logout'])->name('logout');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout.post');

// ============================================
// AUTHENTICATED ROUTES
// ============================================
Route::middleware(['ams.auth'])->group(function () {
    
    // System Selection
    Route::get('/my-systems', [SystemSelectionController::class, 'index'])
        ->name('systems.selection');
    
    Route::get('/my-systems/access/{systemId}', [SystemSelectionController::class, 'accessSystem'])
        ->name('systems.access');

    // ============================================
    // ✅ MAIN DASHBOARD ROUTE (MOVED HERE)
    // ============================================
    // Dipindah keluar dari 'check.admin.role' agar Manager/Head juga bisa akses.
    // DashboardController akan mengatur siapa yang melihat apa (Admin vs Head).
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard.index');

    // ============================================
    // HEAD SECTION ROUTES
    // ============================================
    // Protected by 'check.head.section' middleware
    Route::middleware(['check.head.section'])->prefix('head-section')->name('head.')->group(function () {
        
        // Dashboard Khusus Head (Audits + Transfer Requests)
        Route::get('/dashboard', [\App\Http\Controllers\HeadSectionController::class, 'index'])
            ->name('dashboard');
        
        // Initiate a transfer (Move subordinate OUT)
        Route::post('/transfer/initiate', [\App\Http\Controllers\HeadSectionController::class, 'initiateTransfer'])
            ->name('transfer.initiate');
        
        // Process a transfer (Approve/Reject)
        Route::post('/transfer/{id}/process', [\App\Http\Controllers\HeadSectionController::class, 'processTransfer'])
            ->name('transfer.process');
    });
    
    // ============================================
    // ADMIN ROUTES (Restricted to Roles 0, 1, 2)
    // ============================================
    Route::middleware(['check.admin.role'])->group(function () {
        
        // ❌ Route Dashboard DIHAPUS dari sini karena sudah dipindah ke atas
        
        // ============================================
        // USER MANAGEMENT
        // ============================================
        Route::prefix('users')->name('users.')->group(function () {
            Route::get('/', [UserController::class, 'index'])->name('index');
            Route::get('/create', [UserController::class, 'create'])->name('create');
            Route::post('/', [UserController::class, 'store'])->name('store');
            Route::get('/{id}/edit', [UserController::class, 'edit'])->name('edit');
            Route::put('/{id}', [UserController::class, 'update'])->name('update');
            Route::delete('/{id}', [UserController::class, 'destroy'])->name('destroy');
        });
        
        // ============================================
        // SYSTEM MANAGEMENT
        // ============================================
        Route::prefix('systems')->name('systems.')->group(function () {
            Route::get('/', [SystemController::class, 'index'])->name('index');
            Route::get('/create', [SystemController::class, 'create'])->name('create');
            Route::post('/', [SystemController::class, 'store'])->name('store');
            Route::get('/{id}/edit', [SystemController::class, 'edit'])->name('edit');
            Route::put('/{id}', [SystemController::class, 'update'])->name('update');
            Route::post('/{id}/regenerate-api-key', [SystemController::class, 'regenerateApiKey'])->name('regenerate-api-key');
        });
        
        // ============================================
        // ROLE MANAGEMENT
        // ============================================
        Route::prefix('roles')->name('roles.')->group(function () {
            Route::get('/', [RoleController::class, 'index'])->name('index');
            Route::get('/create', [RoleController::class, 'create'])->name('create');
            Route::post('/', [RoleController::class, 'store'])->name('store');
            Route::get('/{id}/edit', [RoleController::class, 'edit'])->name('edit');
            Route::put('/{id}', [RoleController::class, 'update'])->name('update');
            Route::delete('/{id}', [RoleController::class, 'destroy'])->name('destroy');
            Route::get('/{id}/permissions', [RoleController::class, 'permissions'])->name('permissions');
            Route::post('/{id}/permissions', [RoleController::class, 'updatePermissions'])->name('permissions.update');
        });
        
        // ============================================
        // GROUPS MANAGEMENT
        // ============================================
        Route::prefix('groups')->name('groups.')->group(function () {
            Route::get('/', [GroupController::class, 'index'])->name('index');
            Route::get('/create', [GroupController::class, 'create'])->name('create');
            Route::post('/', [GroupController::class, 'store'])->name('store');
            Route::get('/edit', [GroupController::class, 'edit'])->name('edit');
            Route::post('/update', [GroupController::class, 'update'])->name('update');
            Route::delete('/destroy', [GroupController::class, 'destroy'])->name('destroy');
            Route::get('/members', [GroupController::class, 'members'])->name('members');
        });
        
        // ============================================
        // USER SYSTEM ACCESS MANAGEMENT
        // ============================================
        Route::prefix('access')->name('access.')->group(function () {
            
            Route::get('/system-template/{systemId}', [UserSystemAccessController::class, 'getSystemTemplate'])
                ->name('system-template');
            
            Route::get('/create', [UserSystemAccessController::class, 'create'])
                ->name('create');
            
            Route::post('/bulk-grant', [UserSystemAccessController::class, 'bulkGrant'])
                ->name('bulk-grant');
            
            // Basic CRUD
            Route::get('/', [UserSystemAccessController::class, 'index'])->name('index');
            Route::post('/', [UserSystemAccessController::class, 'store'])->name('store');
            Route::get('/{id}', [UserSystemAccessController::class, 'show'])->name('show');
            Route::get('/{id}/edit', [UserSystemAccessController::class, 'edit'])->name('edit');
            Route::put('/{id}', [UserSystemAccessController::class, 'update'])->name('update');
            Route::delete('/{id}', [UserSystemAccessController::class, 'revoke'])->name('revoke');
            Route::post('/{id}/toggle', [UserSystemAccessController::class, 'toggle'])->name('toggle');
            
            // Group Management
            Route::post('/{id}/add-group', [UserSystemAccessController::class, 'addGroup'])->name('add-group');
            Route::post('/{id}/remove-group', [UserSystemAccessController::class, 'removeGroup'])->name('remove-group');
        });
        
        // ============================================
        // AUDIT TRAIL
        // ============================================
        Route::prefix('audit')->name('audit.')->group(function () {
            Route::get('/', [AuditController::class, 'index'])->name('index');
            Route::get('/export', [AuditController::class, 'export'])->name('export');
            Route::get('/{id}', [AuditController::class, 'show'])->name('show');
        });
        
    });
});

// ============================================
// 404 FALLBACK
// ============================================
Route::fallback(function () {
    return view('errors.404');
});