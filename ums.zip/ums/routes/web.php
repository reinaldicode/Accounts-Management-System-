<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\SystemSelectionController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\SystemController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UserSystemAccessController;
use App\Http\Controllers\AuditController; // ✅ AUDIT TRAIL

/*
|--------------------------------------------------------------------------
| Web Routes - UMS
|--------------------------------------------------------------------------
*/

// Route ini khusus untuk mengecek apakah Extension LDAP sudah aktif di server.
// Akses via: /cek-ldap
Route::get('/cek-ldap', function () {
    if (function_exists('ldap_connect')) {
        return "✅ LDAP Extension AKTIF! Siap digunakan.";
    } else {
        return "❌ LDAP Extension BELUM AKTIF. Silakan buka php.ini, cari ';extension=ldap', hapus titik komanya, lalu restart web server.";
    }
});

// ============================================
// PUBLIC ROUTES
// ============================================
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.post');
});

Route::get('/logout', [AuthController::class, 'logout'])->name('logout');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout.post');

// ============================================
// AUTHENTICATED ROUTES
// ============================================
Route::middleware(['ams.auth'])->group(function () {
    
    // System Selection
    Route::get('/my-systems', [SystemSelectionController::class, 'index'])
        ->name('systems.selection');
    
    Route::get('/my-systems/access/{systemId}', [SystemSelectionController::class, 'accessSystem'])
        ->name('systems.access');
    
    // ============================================
    // ADMIN ROUTES
    // ============================================
    Route::middleware(['check.admin.role'])->group(function () {
        
        // Dashboard
        Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard.index');
        
        // User Management
        Route::prefix('users')->name('users.')->group(function () {
            Route::get('/', [UserController::class, 'index'])->name('index');
            Route::get('/create', [UserController::class, 'create'])->name('create');
            Route::post('/', [UserController::class, 'store'])->name('store');
            Route::get('/{id}/edit', [UserController::class, 'edit'])->name('edit');
            Route::put('/{id}', [UserController::class, 'update'])->name('update');
            Route::delete('/{id}', [UserController::class, 'destroy'])->name('destroy');
        });
        
        // System Management
        Route::prefix('systems')->name('systems.')->group(function () {
            Route::get('/', [SystemController::class, 'index'])->name('index');
            Route::get('/create', [SystemController::class, 'create'])->name('create');
            Route::post('/', [SystemController::class, 'store'])->name('store');
            Route::get('/{id}/edit', [SystemController::class, 'edit'])->name('edit');
            Route::put('/{id}', [SystemController::class, 'update'])->name('update');
            Route::post('/{id}/regenerate-api-key', [SystemController::class, 'regenerateApiKey'])->name('regenerate-api-key');
        });
        
        // Role Management
        Route::prefix('roles')->name('roles.')->group(function () {
            Route::get('/', [RoleController::class, 'index'])->name('index');
            Route::get('/create', [RoleController::class, 'create'])->name('create');
            Route::post('/', [RoleController::class, 'store'])->name('store');
            Route::get('/{id}/edit', [RoleController::class, 'edit'])->name('edit');
            Route::put('/{id}', [RoleController::class, 'update'])->name('update');
            Route::delete('/{id}', [RoleController::class, 'destroy'])->name('destroy');
            Route::get('/{id}/permissions', [RoleController::class, 'permissions'])->name('permissions');
            Route::post('/{id}/permissions', [RoleController::class, 'updatePermissions'])->name('permissions.update');
        });
        
        // ============================================
        // USER SYSTEM ACCESS MANAGEMENT
        // ============================================
        Route::prefix('access')->name('access.')->group(function () {
            
            // Route khusus HARUS di atas route dengan parameter
            Route::get('/system-template/{systemId}', [UserSystemAccessController::class, 'getSystemTemplate'])
                ->name('system-template');
            
            Route::get('/create', [UserSystemAccessController::class, 'create'])
                ->name('create');
            
            Route::post('/bulk-grant', [UserSystemAccessController::class, 'bulkGrant'])
                ->name('bulk-grant');
            
            // Basic CRUD
            Route::get('/', [UserSystemAccessController::class, 'index'])->name('index');
            Route::post('/', [UserSystemAccessController::class, 'store'])->name('store');
            Route::get('/{id}', [UserSystemAccessController::class, 'show'])->name('show');
            Route::get('/{id}/edit', [UserSystemAccessController::class, 'edit'])->name('edit');
            Route::put('/{id}', [UserSystemAccessController::class, 'update'])->name('update');
            Route::delete('/{id}', [UserSystemAccessController::class, 'revoke'])->name('revoke');
            Route::post('/{id}/toggle', [UserSystemAccessController::class, 'toggle'])->name('toggle');
            
            // Group Management
            Route::post('/{id}/add-group', [UserSystemAccessController::class, 'addGroup'])->name('add-group');
            Route::post('/{id}/remove-group', [UserSystemAccessController::class, 'removeGroup'])->name('remove-group');
        });
        
        // ============================================
        // ✅ AUDIT TRAIL - TAMBAHAN BARU
        // ============================================
        Route::prefix('audit')->name('audit.')->group(function () {
            Route::get('/', [AuditController::class, 'index'])->name('index');
            Route::get('/export', [AuditController::class, 'export'])->name('export');
            Route::get('/{id}', [AuditController::class, 'show'])->name('show');
        });
        
    });
});

// 404 Fallback
Route::fallback(function () {
    return view('errors.404');
});