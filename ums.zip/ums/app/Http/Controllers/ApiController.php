<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserSession;
use App\Models\UserSystemAccess;
use App\Models\System;

class ApiController extends Controller
{
    /**
     * Handle SSO Token Validation with Section, Role, Groups support
     */
    public function validateToken(Request $request)
    {
        // 1. Get requesting system (injected by middleware)
        $requestingSystem = $request->requesting_system;

        // 2. Get token from request
        $token = $request->input('token');

        if (!$token) {
            return response()->json([
                'success' => false, 
                'message' => 'Token required'
            ], 400);
        }

        // 3. Validate token in database
        $session = UserSession::where('token', $token)
                    ->where('expires_at', '>', now())
                    ->first();

        if (!$session) {
            return response()->json([
                'success' => false, 
                'message' => 'Invalid or expired token'
            ], 401);
        }

        // 4. Get user from session
        $user = $session->user;

        // 5. Check user access to requesting system
        $access = UserSystemAccess::with('role')
                    ->where('user_id', $user->iduser)
                    ->where('system_id', $requestingSystem->id)
                    ->where('is_active', 1)
                    ->first();

        if (!$access) {
            return response()->json([
                'success' => false,
                'message' => 'User has no access to ' . $requestingSystem->system_name
            ], 403);
        }

        // 6. Parse access_metadata JSON
        $metadata = $access->access_metadata ?? [];

        // 7. Build access control response with COMPLETE validation data
        $accessControl = [
            // Global Role (from roles table)
            'global_role' => $access->role->name,
            'role_id' => $access->role->id,
            
            // Section validation (Validation #1)
            'section' => $metadata['section'] ?? 'Unknown',
            'department' => $metadata['department'] ?? null,
            
            // Role-specific permissions (Validation #2)
            'state' => $metadata['state'] ?? 'Originator', // Approver/Originator/Admin
            'level' => $metadata['level'] ?? 0,
            
            // Groups validation (Validation #3)
            'groups' => $metadata['groups'] ?? [],
            
            // Additional metadata for specific apps
            'custom_permissions' => $metadata['custom_permissions'] ?? [],
            
            // Legacy support (for backward compatibility)
            'permissions' => $metadata // Keep original structure
        ];

        // 8. Delete token (one-time use security)
        $session->delete();

        // 9. Return complete user data with ALL validation fields
        return response()->json([
            'success' => true,
            'user' => [
                'iduser' => $user->iduser,
                'username' => $user->username,
                'empid' => $user->empid,
                'name' => trim($user->firstname . ' ' . ($user->middlename ?? '') . ' ' . $user->lastname),
                'email' => $user->email_corp,
                'email_personal' => $user->email_personal,
                'section' => $user->sectid,
                'department' => $user->deptid,
                'title' => $user->titleid,
                'active' => $user->active
            ],
            'access_control' => $accessControl,
            'system' => [
                'id' => $requestingSystem->id,
                'code' => $requestingSystem->system_code,
                'name' => $requestingSystem->system_name
            ]
        ]);
    }

    /**
     * Check if session is still valid (for auto-logout)
     */
    public function checkSession(Request $request)
    {
        $token = $request->input('token');

        if (!$token) {
            return response()->json(['valid' => false], 400);
        }

        $session = UserSession::where('token', $token)
                    ->where('expires_at', '>', now())
                    ->first();

        return response()->json([
            'valid' => $session !== null,
            'expires_at' => $session?->expires_at
        ]);
    }
}