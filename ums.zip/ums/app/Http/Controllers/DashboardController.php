<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\System;
use App\Models\UserSystemAccess;
use App\Models\AuditLog;
use App\Models\UserSession;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    /**
     * Show dashboard.
     * Bertindak sebagai "Traffic Controller":
     * - Manager/Head -> Redirect ke Head Dashboard
     * - Admin/Super Admin -> Tampilkan Admin Dashboard (SSO Metrics)
     */
    public function index()
    {
        $user = session('ams_user');

        // =========================================================================
        // 1. CEK ROLE UNTUK REDIRECT (Manager & Supervisor)
        // =========================================================================
        // Jika user adalah Manager (3) atau Supervisor (4), lempar ke Dashboard Head.
        if ($user && in_array($user->roleid, [3, 4])) {
            return redirect()->route('head.dashboard');
        }

        // =========================================================================
        // 2. CEK SECURITY (User Biasa Dilarang Masuk)
        // =========================================================================
        // Jika bukan Admin (0,1,2) dan bukan Manager (3,4), tendang ke My Systems
        if ($user && !in_array($user->roleid, [0, 1, 2, 3, 4])) {
            return redirect()->route('systems.selection');
        }

        // =========================================================================
        // 3. LOGIKA DASHBOARD ADMIN (Untuk Role 0, 1, 2)
        // =========================================================================
        
        // Get SSO-focused statistics
        $stats = [
            'total_users' => User::where('active', 'y')->count(),
            'total_systems' => System::where('is_active', 1)->count(),
            'active_sessions' => UserSession::where('expires_at', '>', now())
                ->distinct('user_id')->count('user_id'),
            'today_logins' => AuditLog::whereIn('action', ['login_success', 'sso_login'])
                ->whereDate('created_at', today())->count(),
        ];

        // Get user's accessible systems
        $userSystems = UserSystemAccess::with(['system', 'role'])
            ->where('user_id', $user->iduser)
            ->where('is_active', 1)
            ->whereHas('system', function($query) {
                $query->where('is_active', 1);
            })
            ->where(function($query) {
                $query->whereNull('expires_at')
                      ->orWhere('expires_at', '>', now());
            })
            ->get();

        $recentActivity = AuditLog::with(['user', 'system'])
            ->whereIn('action', [
                'login_success', 'sso_login', 'access_granted', 
                'access_revoked', 'login_failed', 'account_locked'
            ])
            ->orderBy('created_at', 'desc')
            ->limit(15)
            ->get();

        return view('dashboard.index', compact(
            'user', 'stats', 'userSystems', 'recentActivity'
        ));
    }

    public function realtimeStats()
    {
        return response()->json([
            'active_sessions' => UserSession::where('expires_at', '>', now())->distinct('user_id')->count('user_id'),
            'today_logins' => AuditLog::whereIn('action', ['login_success', 'sso_login'])->whereDate('created_at', today())->count(),
            'timestamp' => now()->toISOString(),
        ]);
    }
}