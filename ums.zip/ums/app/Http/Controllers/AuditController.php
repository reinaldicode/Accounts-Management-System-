<?php
// app/Http/Controllers/AuditController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AuditLog;
use App\Models\System;
use Carbon\Carbon;

class AuditController extends Controller
{
    /**
     * Display audit trail dashboard
     */
    public function index(Request $request)
    {
        // Build query with filters
        $query = AuditLog::with(['user', 'system'])
            ->orderBy('created_at', 'desc');
        
        // Filter by action
        if ($request->filled('action')) {
            $query->where('action', $request->action);
        }
        
        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        
        // Filter by user (search by name or username)
        if ($request->filled('user')) {
            $query->whereHas('user', function($q) use ($request) {
                $q->where('username', 'like', '%' . $request->user . '%')
                  ->orWhere('firstname', 'like', '%' . $request->user . '%')
                  ->orWhere('lastname', 'like', '%' . $request->user . '%');
            });
        }
        
        // Filter by IP address
        if ($request->filled('ip')) {
            $query->where('ip_address', 'like', '%' . $request->ip . '%');
        }
        
        // Filter by date range
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }
        
        // Paginate results
        $logs = $query->paginate(50);
        
        // Calculate statistics
        $stats = $this->calculateStats($request);
        
        return view('audit.index', compact('logs', 'stats'));
    }
    
    /**
     * Calculate statistics for dashboard
     */
    private function calculateStats(Request $request)
    {
        $baseQuery = AuditLog::query();
        
        // Apply same filters to stats
        if ($request->filled('date_from')) {
            $baseQuery->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $baseQuery->whereDate('created_at', '<=', $request->date_to);
        }
        
        return [
            'today' => (clone $baseQuery)->whereDate('created_at', today())->count(),
            'login_success' => (clone $baseQuery)->where('action', 'login_success')->count(),
            'login_failed' => (clone $baseQuery)->whereIn('action', ['login_failed', 'login_failed_wrong_password', 'login_failed_locked'])->count(),
            'api_access' => (clone $baseQuery)->where('action', 'api_access')->count(),
            'access_changes' => (clone $baseQuery)->whereIn('action', ['access_granted', 'access_revoked', 'access_updated'])->count(),
        ];
    }
    
    /**
     * Show detailed log entry
     */
    public function show($id)
    {
        $log = AuditLog::with(['user', 'system'])->findOrFail($id);
        
        return response()->json([
            'success' => true,
            'log' => [
                'id' => $log->id,
                'action' => $log->action,
                'status' => $log->status,
                'created_at' => $log->created_at->format('Y-m-d H:i:s'),
                'user' => $log->user ? [
                    'name' => $log->user->firstname . ' ' . $log->user->lastname,
                    'username' => $log->user->username,
                ] : null,
                'system' => $log->system ? [
                    'name' => $log->system->system_name,
                    'code' => $log->system->system_code,
                ] : null,
                'ip_address' => $log->ip_address,
                'user_agent' => $log->user_agent,
                'additional_data' => $log->additional_data,
            ]
        ]);
    }
    
    /**
     * Export audit logs to CSV
     */
    public function export(Request $request)
    {
        $query = AuditLog::with(['user', 'system'])
            ->orderBy('created_at', 'desc');
        
        // Apply same filters as index
        if ($request->filled('action')) {
            $query->where('action', $request->action);
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('user')) {
            $query->whereHas('user', function($q) use ($request) {
                $q->where('username', 'like', '%' . $request->user . '%')
                  ->orWhere('firstname', 'like', '%' . $request->user . '%')
                  ->orWhere('lastname', 'like', '%' . $request->user . '%');
            });
        }
        if ($request->filled('ip')) {
            $query->where('ip_address', 'like', '%' . $request->ip . '%');
        }
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }
        
        $logs = $query->limit(10000)->get(); // Limit to 10k rows
        
        $filename = 'audit_logs_' . date('Y-m-d_His') . '.csv';
        
        $headers = [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            'Pragma' => 'no-cache',
            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
            'Expires' => '0'
        ];
        
        $callback = function() use ($logs) {
            $file = fopen('php://output', 'w');
            
            // Add BOM for proper UTF-8 encoding in Excel
            fprintf($file, chr(0xEF).chr(0xBB).chr(0xBF));
            
            // CSV Header
            fputcsv($file, [
                'Timestamp',
                'Date',
                'Time',
                'User',
                'Username',
                'Action',
                'Status',
                'IP Address',
                'System',
                'System Code',
                'Details (JSON)',
                'User Agent'
            ]);
            
            // CSV Rows
            foreach ($logs as $log) {
                // Format additional data untuk lebih readable
                $details = '';
                if ($log->additional_data) {
                    $detailsArray = [];
                    foreach ($log->additional_data as $key => $value) {
                        if (is_array($value) || is_object($value)) {
                            $detailsArray[] = $key . ': ' . json_encode($value);
                        } else {
                            $detailsArray[] = $key . ': ' . $value;
                        }
                    }
                    $details = implode(' | ', $detailsArray);
                }
                
                fputcsv($file, [
                    $log->created_at->format('Y-m-d H:i:s'),
                    $log->created_at->format('Y-m-d'),
                    $log->created_at->format('H:i:s'),
                    $log->user ? $log->user->firstname . ' ' . $log->user->lastname : 'System',
                    $log->user ? $log->user->username : '-',
                    str_replace('_', ' ', ucwords($log->action)),
                    ucfirst($log->status),
                    $log->ip_address ?? '-',
                    $log->system ? $log->system->system_name : '-',
                    $log->system ? $log->system->system_code : '-',
                    $details,
                    $log->user_agent ?? '-',
                ]);
            }
            
            fclose($file);
        };
        
        return response()->stream($callback, 200, $headers);
    }
    
    /**
     * Get activity chart data (for future dashboard charts)
     */
    public function chartData(Request $request)
    {
        $days = $request->input('days', 7);
        
        $data = [];
        for ($i = $days - 1; $i >= 0; $i--) {
            $date = Carbon::today()->subDays($i);
            
            $data[] = [
                'date' => $date->format('M d'),
                'logins' => AuditLog::whereDate('created_at', $date)
                    ->where('action', 'login_success')
                    ->count(),
                'failed' => AuditLog::whereDate('created_at', $date)
                    ->whereIn('action', ['login_failed', 'login_failed_wrong_password'])
                    ->count(),
                'api_calls' => AuditLog::whereDate('created_at', $date)
                    ->where('action', 'api_access')
                    ->count(),
            ];
        }
        
        return response()->json([
            'success' => true,
            'data' => $data
        ]);
    }
}