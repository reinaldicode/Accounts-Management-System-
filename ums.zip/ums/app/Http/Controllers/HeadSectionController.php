<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\AuditLog;
use App\Models\SectionTransfer;
use Illuminate\Support\Facades\DB;

class HeadSectionController extends Controller
{
    /**
     * Dashboard khusus Head Section
     * Menampilkan Audit Log anak buah & Request Transfer
     */
    public function index()
    {
        // 1. Identify Current Head's Section
        // Assumption: Head's section is stored in their user table 'sectid'
        $headUser = session('ams_user');
        $mySection = $headUser->sectid; 

        if (!$mySection) {
            return back()->with('error', 'Anda tidak memiliki assignment section.');
        }

        // 2. Get Subordinates (Anak Buah)
        // Users in the same section, excluding the Head himself
        $subordinates = User::where('sectid', $mySection)
                            ->where('iduser', '!=', $headUser->iduser)
                            ->get();

        $subordinateIds = $subordinates->pluck('iduser');

        // 3. Get Audit Logs of Subordinates
        $teamAudits = AuditLog::with('user', 'system')
                        ->whereIn('user_id', $subordinateIds)
                        ->orderBy('created_at', 'desc')
                        ->limit(50)
                        ->get();

        // 4. Get Pending Transfers
        // A. Users wanting to LEAVE my section (Need Exit Approval)
        $outgoingRequests = SectionTransfer::with('user')
                            ->where('from_section', $mySection)
                            ->where('status', 'pending_exit')
                            ->get();

        // B. Users wanting to ENTER my section (Need Entry Approval)
        $incomingRequests = SectionTransfer::with('user')
                            ->where('to_section', $mySection)
                            ->where('status', 'pending_entry')
                            ->get();

        return view('head_section.dashboard', compact(
            'headUser', 'subordinates', 'teamAudits', 'outgoingRequests', 'incomingRequests'
        ));
    }

    /**
     * Initiate a Transfer (Admin or HR does this, or the current Head)
     */
    public function initiateTransfer(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:user,iduser',
            'target_section' => 'required|string|max:10',
            'remarks' => 'nullable|string'
        ]);

        $user = User::findOrFail($request->user_id);

        if ($user->sectid === $request->target_section) {
            return back()->with('error', 'User sudah berada di section tersebut.');
        }

        SectionTransfer::create([
            'user_id' => $user->iduser,
            'from_section' => $user->sectid,
            'to_section' => $request->target_section,
            'status' => 'pending_exit', // Step 1
            'remarks' => $request->remarks
        ]);

        AuditLog::log(session('ams_user_id'), null, 'transfer_initiated', 'success', [
            'target_user' => $user->username,
            'to_section' => $request->target_section
        ]);

        return back()->with('success', 'Request transfer dibuat. Menunggu Exit Approval.');
    }

    /**
     * Handle Approval Actions (Approve Exit / Approve Entry / Reject)
     */
    public function processTransfer(Request $request, $id)
    {
        $transfer = SectionTransfer::findOrFail($id);
        $action = $request->input('action'); // 'approve' or 'reject'
        $currentUser = session('ams_user');

        try {
            DB::beginTransaction();

            if ($action === 'reject') {
                $transfer->update(['status' => 'rejected']);
                AuditLog::log($currentUser->iduser, null, 'transfer_rejected', 'denied', ['transfer_id' => $id]);
                DB::commit();
                return back()->with('success', 'Transfer ditolak.');
            }

            // --- STEP 1: EXIT APPROVAL ---
            if ($transfer->status === 'pending_exit') {
                // Validate if Current User is the Head of 'from_section'
                if ($currentUser->sectid !== $transfer->from_section) {
                    abort(403, 'Anda bukan Head dari Section asal.');
                }

                $transfer->update([
                    'status' => 'pending_entry', // Move to next step
                    'approved_by_exit' => $currentUser->iduser,
                    'exit_approved_at' => now()
                ]);

                AuditLog::log($currentUser->iduser, null, 'transfer_exit_approved', 'success', ['transfer_id' => $id]);
                DB::commit();
                return back()->with('success', 'Exit disetujui. Menunggu approval section baru.');
            }

            // --- STEP 2: ENTRY APPROVAL (FINAL) ---
            if ($transfer->status === 'pending_entry') {
                // Validate if Current User is the Head of 'to_section'
                if ($currentUser->sectid !== $transfer->to_section) {
                    abort(403, 'Anda bukan Head dari Section tujuan.');
                }

                // 1. Update Transfer Record
                $transfer->update([
                    'status' => 'completed',
                    'approved_by_entry' => $currentUser->iduser,
                    'entry_approved_at' => now()
                ]);

                // 2. ACTUALLY MOVE THE USER IN DATABASE
                $targetUser = User::findOrFail($transfer->user_id);
                $oldSection = $targetUser->sectid;
                $targetUser->update([
                    'sectid' => $transfer->to_section
                ]);

                AuditLog::log($currentUser->iduser, null, 'transfer_completed', 'success', [
                    'user' => $targetUser->username,
                    'from' => $oldSection,
                    'to' => $transfer->to_section
                ]);

                DB::commit();
                return back()->with('success', 'Transfer selesai. User telah pindah ke section Anda.');
            }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Error: ' . $e->getMessage());
        }
    }
}