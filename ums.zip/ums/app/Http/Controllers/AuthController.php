<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\User;
use App\Models\AuditLog;
use App\Models\UserSession;
use App\Helpers\AMSHelper;

class AuthController extends Controller
{
    /**
     * Show login page
     */
    public function showLogin(Request $request)
    {
        $returnUrl = $request->query('return_url');
        $systemCode = $request->query('system');

        if (session()->has('ams_user')) {
            $user = session('ams_user');
            if ($returnUrl) {
                return $this->generateSsoTokenAndRedirect($user, $returnUrl);
            }
            return $this->redirectAfterLogin($user);
        }

        return view('auth.login', compact('returnUrl', 'systemCode'));
    }

    /**
     * Handle login HYBRID (LDAP + DATABASE PLAIN TEXT)
     */
    public function login(Request $request)
    {
        // 1. Validasi Input
        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);

        $inputUsername = strtolower($request->input('username'));
        $inputPassword = $request->input('password');

        // Logic Trim "gzb" (Legacy Support)
        // Jika user ketik "gzbjavier", jadi "javier". Jika "javier", tetap "javier".
        $cleanUsername = trim($inputUsername, "gzb");

        // ------------------------------------------------------------------
        // STEP 1: Cek User di Database Lokal (Authorisasi)
        // ------------------------------------------------------------------
        // Kita cari user dulu. Kalau user tidak ada di DB, tolak langsung.
        $user = User::where('username', $cleanUsername)->first();

        if (!$user) {
            AuditLog::log(null, null, 'login_failed', 'failed', [
                'username' => $cleanUsername,
                'reason' => 'user_not_found'
            ]);
            return back()->with('error', 'Username tidak terdaftar di sistem ini.')->withInput();
        }

        // ------------------------------------------------------------------
        // STEP 2: Cek Status Akun (Locked / Inactive)
        // ------------------------------------------------------------------
        if ($user->isLocked()) {
            AuditLog::log($user->iduser, null, 'login_failed_locked', 'denied');
            return back()->with('error', 'Akun terkunci sampai ' . $user->locked_until->format('d/m/Y H:i'))->withInput();
        }

        if (!$user->isActive()) {
            AuditLog::log($user->iduser, null, 'login_failed_inactive', 'denied');
            return back()->with('error', 'Akun Anda tidak aktif. Hubungi Admin.')->withInput();
        }

        // ------------------------------------------------------------------
        // STEP 3: LOGIC AUTENTIKASI (LDAP -> FALLBACK DB PLAIN TEXT)
        // ------------------------------------------------------------------
        $isAuthenticated = false;
        $authMethod = 'None';

        // --- A. COBA LDAP (Active Directory) ---
        // Ambil config dari .env
        $ldapHost = env('LDAP_HOST', 'ldap://ASIASHARP.com'); 
        $ldapDn   = env('LDAP_PREFIX', 'GZB') . $cleanUsername . env('LDAP_SUFFIX', '@ASIASHARP.COM');

        // Cek koneksi LDAP
        if (function_exists('ldap_connect')) {
            $ldapConn = @ldap_connect($ldapHost);
            if ($ldapConn) {
                // Set options standar LDAP
                ldap_set_option($ldapConn, LDAP_OPT_PROTOCOL_VERSION, 3);
                ldap_set_option($ldapConn, LDAP_OPT_REFERRALS, 0);

                // Coba Bind (Login)
                $bind = @ldap_bind($ldapConn, $ldapDn, $inputPassword);
                
                if ($bind) {
                    $isAuthenticated = true;
                    $authMethod = 'LDAP';
                    @ldap_unbind($ldapConn);
                }
            }
        }

        // --- B. JIKA LDAP GAGAL, COBA DB LOKAL (PLAIN TEXT) ---
        if (!$isAuthenticated) {
            // PERBAIKAN: Langsung bandingkan string vs string (Case Sensitive)
            if ($user->password === $inputPassword) {
                $isAuthenticated = true;
                $authMethod = 'Database (Plain)';
            }
        }

        // ------------------------------------------------------------------
        // STEP 4: EKSEKUSI HASIL LOGIN
        // ------------------------------------------------------------------
        
        // GAGAL LOGIN
        if (!$isAuthenticated) {
            $user->incrementFailedAttempts();
            
            // Cek apakah harus dikunci (Max Attempts)
            $maxAttempts = AMSHelper::getMaxLoginAttempts(); // Pastikan Helper ini ada
            
            if ($user->failed_login_attempts >= $maxAttempts) {
                $lockoutDuration = AMSHelper::getLockoutDuration();
                $user->lockAccount($lockoutDuration);

                AuditLog::log($user->iduser, null, 'account_locked', 'denied', [
                    'failed_attempts' => $user->failed_login_attempts
                ]);

                return back()->with('error', 'Akun terkunci karena terlalu banyak percobaan gagal.');
            }

            AuditLog::log($user->iduser, null, 'login_failed_wrong_password', 'failed');
            return back()->with('error', 'Password salah (LDAP & Local gagal).')->withInput();
        }

        // BERHASIL LOGIN
        $user->resetFailedAttempts();
        $user->update(['last_login_at' => now()]);

        // Simpan Session Manual (Sesuai request User)
        session([
            'ams_user' => $user,
            'ams_user_id' => $user->iduser, // Menggunakan iduser dari Model
            'ams_username' => $user->username,
            'ams_fullname' => trim($user->firstname . ' ' . $user->lastname),
            'ams_auth_method' => $authMethod, // Berguna untuk debugging
            'ams_login_time' => now(),
        ]);

        AuditLog::log($user->iduser, null, 'login_success', 'success', ['method' => $authMethod]);

        // Redirect Logic
        $returnUrl = $request->input('return_url');
        if ($returnUrl) {
            return $this->generateSsoTokenAndRedirect($user, $returnUrl);
        }

        return $this->redirectAfterLogin($user);
    }

    // --- HELPER METHODS ---

    private function redirectAfterLogin($user)
    {
        $globalRole = $user->roleid; 
        if (in_array($globalRole, [0, 1, 2])) {
            return redirect()->route('dashboard');
        }
        return redirect()->route('systems.selection');
    }

    private function generateSsoTokenAndRedirect($user, $returnUrl)
    {
        $token = Str::random(64);
        UserSession::create([
            'user_id' => $user->iduser,
            'token' => $token,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'expires_at' => now()->addMinutes(2), 
            'last_activity_at' => now()
        ]);
        
        $separator = (parse_url($returnUrl, PHP_URL_QUERY) == NULL) ? '?' : '&';
        return redirect($returnUrl . $separator . 'token=' . $token);
    }

    public function logout(Request $request)
    {
        $userId = session('ams_user_id');
        $returnTo = $request->query('return_to');
        
        if ($userId) {
            $action = $returnTo ? 'full_logout' : 'logout';
            AuditLog::log($userId, null, $action, 'success');
            if ($returnTo) {
                UserSession::where('user_id', $userId)->delete();
            }
        }
        session()->flush();

        if ($returnTo) {
             return redirect($returnTo);
        }
        return redirect()->route('login')->with('success', 'Anda telah logout');
    }
}