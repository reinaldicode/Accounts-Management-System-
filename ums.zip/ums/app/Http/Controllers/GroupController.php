<?php
// app/Http/Controllers/GroupController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\System;
use App\Models\UserSystemAccess;
use App\Models\AuditLog;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class GroupController extends Controller
{
    /**
     * Display groups for a specific system
     */
    public function index(Request $request)
    {
        $systems = System::where('is_active', 1)->orderBy('system_name')->get();
        
        // Selected system
        $selectedSystemId = $request->get('system_id');
        $groups = [];
        $selectedSystem = null;
        
        if ($selectedSystemId) {
            $selectedSystem = System::find($selectedSystemId);
            if ($selectedSystem) {
                $groups = $this->getSystemGroups($selectedSystem);
            }
        }
        
        return view('groups.index', compact('systems', 'selectedSystem', 'groups'));
    }
    
    /**
     * Show form to add new group
     */
    public function create(Request $request)
    {
        $systemId = $request->get('system_id');
        $system = System::findOrFail($systemId);
        
        return view('groups.create', compact('system'));
    }
    
    /**
     * Store new group
     */
    public function store(Request $request)
    {
        $request->validate([
            'system_id' => 'required|exists:systems,id',
            'group_name' => 'required|string|max:100',
            'description' => 'nullable|string|max:500',
        ]);
        
        try {
            DB::beginTransaction();
            
            $system = System::findOrFail($request->system_id);
            $template = $system->permission_template;
            
            // Decode if string
            if (is_string($template)) {
                $template = json_decode($template, true) ?? ['fields' => []];
            }
            
            // ✅ FIXED: Gunakan key 'groups' bukan 'available_groups'
            if (!isset($template['groups'])) {
                $template['groups'] = [];
            }
            
            // Check duplicate
            $groupName = trim($request->group_name);
            foreach ($template['groups'] as $existingGroup) {
                if (strcasecmp($existingGroup['name'], $groupName) === 0) {
                    return back()->withErrors(['group_name' => 'Group already exists in this system'])->withInput();
                }
            }
            
            // Add new group
            $template['groups'][] = [
                'name' => $groupName,
                'description' => $request->description ?? '',
                'created_at' => now()->toISOString(),
                'created_by' => session('ams_username'),
            ];
            
            // Update system
            $system->permission_template = $template;
            $system->save();
            
            // Audit log
            AuditLog::log(
                session('ams_user_id'),
                $system->id,
                'group_created',
                'success',
                [
                    'group_name' => $groupName,
                    'system_code' => $system->system_code,
                ]
            );
            
            DB::commit();
            
            return redirect()->route('groups.index', ['system_id' => $system->id])
                ->with('success', "Group '$groupName' created successfully");
            
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error creating group', [
                'error' => $e->getMessage(),
                'request' => $request->all()
            ]);
            return back()->withErrors(['error' => 'Failed to create group: ' . $e->getMessage()])->withInput();
        }
    }
    
    /**
     * Show edit form
     */
    public function edit(Request $request)
    {
        $systemId = $request->get('system_id');
        $groupIndex = $request->get('index');
        
        $system = System::findOrFail($systemId);
        $groups = $this->getSystemGroups($system);
        
        if (!isset($groups[$groupIndex])) {
            abort(404, 'Group not found');
        }
        
        $group = $groups[$groupIndex];
        $group['index'] = $groupIndex;
        
        return view('groups.edit', compact('system', 'group'));
    }
    
    /**
     * Update group
     */
    public function update(Request $request)
    {
        $request->validate([
            'system_id' => 'required|exists:systems,id',
            'index' => 'required|integer',
            'group_name' => 'required|string|max:100',
            'description' => 'nullable|string|max:500',
        ]);
        
        try {
            DB::beginTransaction();
            
            $system = System::findOrFail($request->system_id);
            $template = $system->permission_template;
            
            if (is_string($template)) {
                $template = json_decode($template, true) ?? ['fields' => []];
            }
            
            // ✅ FIXED: Gunakan key 'groups'
            if (!isset($template['groups'][$request->index])) {
                return back()->withErrors(['error' => 'Group not found']);
            }
            
            $oldName = $template['groups'][$request->index]['name'];
            $newName = trim($request->group_name);
            
            // Check duplicate (exclude current)
            foreach ($template['groups'] as $idx => $existingGroup) {
                if ($idx != $request->index && strcasecmp($existingGroup['name'], $newName) === 0) {
                    return back()->withErrors(['group_name' => 'Group name already exists'])->withInput();
                }
            }
            
            // Update group
            $template['groups'][$request->index] = [
                'name' => $newName,
                'description' => $request->description ?? '',
                'created_at' => $template['groups'][$request->index]['created_at'] ?? now()->toISOString(),
                'created_by' => $template['groups'][$request->index]['created_by'] ?? session('ams_username'),
                'updated_at' => now()->toISOString(),
                'updated_by' => session('ams_username'),
            ];
            
            $system->permission_template = $template;
            $system->save();
            
            // Update all user access yang pakai group lama
            if ($oldName !== $newName) {
                $this->updateUserGroupNames($system->id, $oldName, $newName);
            }
            
            AuditLog::log(
                session('ams_user_id'),
                $system->id,
                'group_updated',
                'success',
                [
                    'old_name' => $oldName,
                    'new_name' => $newName,
                ]
            );
            
            DB::commit();
            
            return redirect()->route('groups.index', ['system_id' => $system->id])
                ->with('success', "Group updated successfully");
            
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error updating group', ['error' => $e->getMessage()]);
            return back()->withErrors(['error' => 'Failed to update group: ' . $e->getMessage()])->withInput();
        }
    }
    
    /**
     * Delete group
     */
    public function destroy(Request $request)
    {
        $systemId = $request->get('system_id');
        $groupIndex = $request->get('index');
        
        try {
            DB::beginTransaction();
            
            $system = System::findOrFail($systemId);
            $template = $system->permission_template;
            
            if (is_string($template)) {
                $template = json_decode($template, true) ?? ['fields' => []];
            }
            
            // ✅ FIXED: Gunakan key 'groups'
            if (!isset($template['groups'][$groupIndex])) {
                return back()->withErrors(['error' => 'Group not found']);
            }
            
            $groupName = $template['groups'][$groupIndex]['name'];
            
            // Check if group is being used
            $usageCount = $this->countGroupUsage($system->id, $groupName);
            
            if ($usageCount > 0) {
                return back()->withErrors([
                    'error' => "Cannot delete group '$groupName'. It is currently assigned to $usageCount user(s). Please remove all assignments first."
                ]);
            }
            
            // Remove group
            array_splice($template['groups'], $groupIndex, 1);
            
            $system->permission_template = $template;
            $system->save();
            
            AuditLog::log(
                session('ams_user_id'),
                $system->id,
                'group_deleted',
                'success',
                ['group_name' => $groupName]
            );
            
            DB::commit();
            
            return redirect()->route('groups.index', ['system_id' => $system->id])
                ->with('success', "Group '$groupName' deleted successfully");
            
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error deleting group', ['error' => $e->getMessage()]);
            return back()->withErrors(['error' => 'Failed to delete group: ' . $e->getMessage()]);
        }
    }
    
    /**
     * Show users in a group
     */
    public function members(Request $request)
    {
        $systemId = $request->get('system_id');
        $groupIndex = $request->get('index');
        
        $system = System::findOrFail($systemId);
        $groups = $this->getSystemGroups($system);
        
        if (!isset($groups[$groupIndex])) {
            abort(404, 'Group not found');
        }
        
        $group = $groups[$groupIndex];
        $groupName = $group['name'];
        
        // Get all users with this group
        $members = UserSystemAccess::with(['user', 'role'])
            ->where('system_id', $systemId)
            ->get()
            ->filter(function($access) use ($groupName) {
                $userGroups = $access->getGroups();
                return in_array($groupName, $userGroups);
            });
        
        return view('groups.members', compact('system', 'group', 'members', 'groupName'));
    }
    
    // ========== HELPER METHODS ==========
    
    /**
     * ✅ FIXED: Get groups from system's permission template
     * Gunakan key 'groups' bukan 'available_groups'
     */
    private function getSystemGroups(System $system)
    {
        $template = $system->permission_template;
        
        if (is_string($template)) {
            $template = json_decode($template, true);
        }
        
        return $template['groups'] ?? [];
    }
    
    /**
     * Update group name in all user access records
     */
    private function updateUserGroupNames($systemId, $oldName, $newName)
    {
        $accesses = UserSystemAccess::where('system_id', $systemId)->get();
        
        foreach ($accesses as $access) {
            $metadata = $access->access_metadata;
            
            if (isset($metadata['groups']) && is_array($metadata['groups'])) {
                $updated = false;
                foreach ($metadata['groups'] as $key => $groupName) {
                    if (strcasecmp($groupName, $oldName) === 0) {
                        $metadata['groups'][$key] = $newName;
                        $updated = true;
                    }
                }
                
                if ($updated) {
                    $access->access_metadata = $metadata;
                    $access->save();
                }
            }
        }
    }
    
    /**
     * Count how many users are in this group
     */
    private function countGroupUsage($systemId, $groupName)
    {
        return UserSystemAccess::where('system_id', $systemId)
            ->get()
            ->filter(function($access) use ($groupName) {
                $groups = $access->getGroups();
                return in_array($groupName, $groups);
            })
            ->count();
    }
}