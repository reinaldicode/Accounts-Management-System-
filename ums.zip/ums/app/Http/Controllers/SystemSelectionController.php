<?php
// app/Http/Controllers/SystemSelectionController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserSystemAccess;
use App\Models\AuditLog;

class SystemSelectionController extends Controller
{
    /**
     * Show system selection page (untuk regular user)
     */
    public function index()
    {
        $user = session('ams_user');
        
        if (!$user) {
            return redirect()->route('login');
        }
        
        // Get systems yang user punya akses
        $userSystems = UserSystemAccess::with(['system', 'role'])
            ->where('user_id', $user->iduser)
            ->where('is_active', 1)
            ->whereHas('system', function($query) {
                $query->where('is_active', 1);
            })
            ->where(function($query) {
                $query->whereNull('expires_at')
                      ->orWhere('expires_at', '>', now());
            })
            ->get();
        
        // Jika user tidak punya akses ke system manapun
        if ($userSystems->isEmpty()) {
            return view('systems.no-access', compact('user'));
        }
        
        return view('systems.selection', compact('user', 'userSystems'));
    }
    
    /**
     * Handle system access request
     * Generate SSO token dan redirect ke system
     */
    public function accessSystem($systemId)
    {
        $user = session('ams_user');
        
        if (!$user) {
            return redirect()->route('login');
        }
        
        // Verify user has access to this system
        $access = UserSystemAccess::with('system')
            ->where('user_id', $user->iduser)
            ->where('system_id', $systemId)
            ->where('is_active', 1)
            ->first();
        
        if (!$access) {
            AuditLog::log($user->iduser, $systemId, 'access_denied', 'denied', [
                'reason' => 'no_access_rights'
            ]);
            
            return back()->with('error', 'Anda tidak memiliki akses ke sistem ini');
        }
        
        // Generate SSO token
        $token = \Illuminate\Support\Str::random(64);
        
        \App\Models\UserSession::create([
            'user_id' => $user->iduser,
            'token' => $token,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'expires_at' => now()->addMinutes(2),
            'last_activity_at' => now()
        ]);
        
        // Log access
        AuditLog::log($user->iduser, $systemId, 'system_access', 'success', [
            'system_name' => $access->system->system_name
        ]);
        
        // Build callback URL
        $callbackUrl = $access->system->system_url . '/sso_callback.php';
        $separator = (parse_url($callbackUrl, PHP_URL_QUERY) == NULL) ? '?' : '&';
        
        return redirect($callbackUrl . $separator . 'token=' . $token);
    }
}