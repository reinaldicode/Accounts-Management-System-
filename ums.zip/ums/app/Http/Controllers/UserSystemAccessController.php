<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserSystemAccess;
use App\Models\User;
use App\Models\System;
use App\Models\Role;
use App\Models\AuditLog;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class UserSystemAccessController extends Controller
{
    /**
     * Display user access list with filters
     */
    public function index(Request $request)
    {
        $query = UserSystemAccess::with(['user', 'system', 'role', 'grantedBy'])
                    ->orderBy('created_at', 'desc');

        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        if ($request->filled('system_id')) {
            $query->where('system_id', $request->system_id);
        }

        if ($request->filled('status')) {
            if ($request->status === 'active') {
                $query->where('is_active', 1);
            } elseif ($request->status === 'inactive') {
                $query->where('is_active', 0);
            }
        }

        if ($request->filled('section')) {
            $query->whereJsonContains('access_metadata->section', $request->section);
        }

        $accesses = $query->paginate(20);

        $users = User::where('active', 'y')->orderBy('firstname')->get();
        $systems = System::where('is_active', 1)->orderBy('system_name')->get();
        
        $sections = UserSystemAccess::whereNotNull('access_metadata')
            ->get()
            ->pluck('access_metadata.section')
            ->filter()
            ->unique()
            ->sort()
            ->values();

        return view('access.index', compact('accesses', 'users', 'systems', 'sections'));
    }

    /**
     * Show create form
     */
    public function create()
    {
        $users = User::where('active', 'y')->orderBy('firstname')->get();
        $systems = System::where('is_active', 1)->orderBy('system_name')->get();
        $roles = Role::orderBy('name')->get();

        return view('access.create', compact('users', 'systems', 'roles'));
    }

    /**
     * ✅ FIXED: API endpoint to get system permission template
     */
    public function getSystemTemplate($systemId)
    {
        try {
            $system = System::find($systemId);
            
            if (!$system) {
                Log::error('System not found', ['system_id' => $systemId]);
                return response()->json([
                    'success' => false,
                    'message' => 'System not found'
                ], 404);
            }
            
            // Get permission_template
            $template = $system->permission_template;
            
            Log::info('Raw permission_template', [
                'system_id' => $systemId,
                'system_code' => $system->system_code,
                'template_type' => gettype($template),
                'template_raw' => $template
            ]);
            
            // ✅ Decode JSON jika string
            if (is_string($template)) {
                $decoded = json_decode($template, true);
                
                if (json_last_error() === JSON_ERROR_NONE) {
                    $template = $decoded;
                    Log::info('Template decoded successfully', ['template' => $template]);
                } else {
                    Log::error('JSON decode error', [
                        'error' => json_last_error_msg(),
                        'template' => $template
                    ]);
                    $template = $this->getDefaultTemplate();
                }
            }
            
            // Jika null atau empty
            if (empty($template)) {
                Log::warning('Empty template, using default', ['system_id' => $systemId]);
                $template = $this->getDefaultTemplate();
            }
            
            // Validasi struktur
            if (!isset($template['fields']) || !is_array($template['fields'])) {
                Log::error('Invalid template structure', ['template' => $template]);
                $template = $this->getDefaultTemplate();
            }
            
            return response()->json([
                'success' => true,
                'system' => [
                    'id' => $system->id,
                    'code' => $system->system_code,
                    'name' => $system->system_name,
                ],
                'template' => $template
            ]);
            
        } catch (\Exception $e) {
            Log::error('Error in getSystemTemplate', [
                'system_id' => $systemId,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Error loading permission template: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Default template
     */
    private function getDefaultTemplate()
    {
        return [
            'fields' => [
                [
                    'name' => 'section',
                    'label' => 'Section',
                    'type' => 'text',
                    'required' => true,
                    'placeholder' => 'e.g., Engineering Section'
                ],
                [
                    'name' => 'state',
                    'label' => 'User State',
                    'type' => 'select',
                    'required' => true,
                    'options' => [
                        ['value' => 'Admin', 'label' => 'Admin'],
                        ['value' => 'Approver', 'label' => 'Approver'],
                        ['value' => 'Originator', 'label' => 'Originator'],
                        ['value' => 'Viewer', 'label' => 'Viewer']
                    ]
                ]
            ]
        ];
    }

    /**
     * Get available groups untuk form
     */
    private function getAvailableGroups()
    {
        return [
            'Finance',
            'HR',
            'IT',
            'Operations',
            'Sales',
            'Marketing',
            'Procurement',
            'Legal',
            'Management',
            'Admin',
            'Engineering',
            'Quality Control',
            'Research & Development',
            'Customer Service',
            'Logistics'
        ];
    }

    /**
     * Store new access
     */
    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:user,iduser',
            'system_id' => 'required|exists:systems,id',
            'role_id' => 'required|exists:roles,id',
            'expires_at' => 'nullable|date|after:today',
            'metadata' => 'required|array',
        ]);

        try {
            DB::beginTransaction();

            $existingAccess = UserSystemAccess::where('user_id', $request->user_id)
                ->where('system_id', $request->system_id)
                ->first();

            if ($existingAccess) {
                return back()->withErrors(['error' => 'User already has access to this system'])->withInput();
            }

            $metadata = array_filter($request->input('metadata', []), function($value) {
                return !is_null($value) && $value !== '';
            });

            $access = UserSystemAccess::create([
                'user_id' => $request->user_id,
                'system_id' => $request->system_id,
                'role_id' => $request->role_id,
                'is_active' => 1,
                'granted_at' => now(),
                'granted_by' => session('ams_user_id'),
                'expires_at' => $request->expires_at,
                'access_metadata' => $metadata,
            ]);

            AuditLog::log(
                session('ams_user_id'),
                $request->system_id,
                'access_granted',
                'success',
                [
                    'target_user_id' => $request->user_id,
                    'role_id' => $request->role_id,
                    'metadata' => $metadata,
                ]
            );

            DB::commit();

            return redirect()->route('access.index')
                ->with('success', 'Access granted successfully');

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error granting access', [
                'error' => $e->getMessage(),
                'request' => $request->all()
            ]);
            return back()->withErrors(['error' => 'Failed to grant access: ' . $e->getMessage()])->withInput();
        }
    }

    /**
     * Show access detail
     */
    public function show($id)
    {
        $access = UserSystemAccess::with(['user', 'system', 'role', 'grantedBy'])
            ->findOrFail($id);

        return view('access.show', compact('access'));
    }

    /**
     * ✅ FIXED: Show edit form with availableGroups
     */
    public function edit($id)
    {
        $access = UserSystemAccess::with(['user', 'system', 'role'])->findOrFail($id);
        $roles = Role::orderBy('name')->get();
        
        // ✅ TAMBAHKAN INI - Get available groups
        $availableGroups = $this->getAvailableGroups();

        return view('access.edit', compact('access', 'roles', 'availableGroups'));
    }

    /**
     * ✅ FIXED: Update access with proper validation
     */
    public function update(Request $request, $id)
    {
        $access = UserSystemAccess::findOrFail($id);

        $request->validate([
            'role_id' => 'required|exists:roles,id',
            'expires_at' => 'nullable|date|after:today',
            'metadata' => 'required|array',
            'metadata.section' => 'required|string',
            'metadata.state' => 'required|string|in:Admin,Approver,Originator,Viewer',
            'metadata.level' => 'nullable|integer|min:0|max:10',
            'metadata.groups' => 'nullable|array',
            'metadata.groups.*' => 'string',
        ]);

        try {
            DB::beginTransaction();

            $metadata = array_filter($request->input('metadata', []), function($value) {
                return !is_null($value) && $value !== '';
            });

            $access->update([
                'role_id' => $request->role_id,
                'expires_at' => $request->expires_at,
                'access_metadata' => $metadata,
            ]);

            AuditLog::log(
                session('ams_user_id'),
                $access->system_id,
                'access_updated',
                'success',
                [
                    'target_user_id' => $access->user_id,
                    'role_id' => $request->role_id,
                    'metadata' => $metadata,
                ]
            );

            DB::commit();

            return redirect()->route('access.index')
                ->with('success', 'Access updated successfully');

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error updating access', [
                'error' => $e->getMessage(),
                'access_id' => $id,
                'request' => $request->all()
            ]);
            return back()->withErrors(['error' => 'Failed to update access: ' . $e->getMessage()])->withInput();
        }
    }

    /**
     * Toggle access status
     */
    public function toggle($id)
    {
        try {
            $access = UserSystemAccess::findOrFail($id);
            $newStatus = !$access->is_active;

            $access->update(['is_active' => $newStatus]);

            AuditLog::log(
                session('ams_user_id'),
                $access->system_id,
                'access_toggled',
                'success',
                [
                    'target_user_id' => $access->user_id,
                    'new_status' => $newStatus ? 'active' : 'inactive'
                ]
            );

            $message = $newStatus ? 'Access activated' : 'Access deactivated';
            return back()->with('success', $message);

        } catch (\Exception $e) {
            return back()->withErrors(['error' => 'Failed to toggle access: ' . $e->getMessage()]);
        }
    }

    /**
     * Revoke/Delete access
     */
    public function revoke($id)
    {
        try {
            $access = UserSystemAccess::findOrFail($id);

            AuditLog::log(
                session('ams_user_id'),
                $access->system_id,
                'access_revoked',
                'success',
                [
                    'target_user_id' => $access->user_id,
                    'role_id' => $access->role_id
                ]
            );

            $access->delete();

            return back()->with('success', 'Access revoked successfully');

        } catch (\Exception $e) {
            return back()->withErrors(['error' => 'Failed to revoke access: ' . $e->getMessage()]);
        }
    }
}