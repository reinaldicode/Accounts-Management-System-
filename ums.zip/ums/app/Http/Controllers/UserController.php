<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str; // Penting untuk random password
use App\Models\User;
use App\Models\AuditLog;

class UserController extends Controller
{
    /**
     * Display user list
     */
    public function index()
    {
        $users = User::orderBy('created_at', 'desc')->paginate(20);
        return view('users.index', compact('users'));
    }

    /**
     * Show create user form
     */
    public function create()
    {
        return view('users.create');
    }

    /**
     * Store new user
     */
    public function store(Request $request)
    {
        // 1. Validasi Umum (Username, Nama, Email)
        // Note: Password divalidasi nanti tergantung pilihan LDAP/Lokal
        $request->validate([
            'empid' => 'required|string|max:10|unique:user,empid',
            'username' => 'required|string|max:10|unique:user,username',
            'firstname' => 'required|string|max:50',
            'middlename' => 'nullable|string|max:50',
            'lastname' => 'nullable|string|max:50',
            'email_corp' => 'nullable|email|max:50',
            'email_personal' => 'nullable|email|max:50',
            'is_ldap' => 'nullable|in:0,1'
        ]);

        // 2. Logic Password & LDAP
        $isLdap = $request->input('is_ldap') == '1';
        $finalPassword = '';

        if ($isLdap) {
            // JIKA LDAP:
            // Kita generate password acak yang panjang.
            // Tujuannya agar kolom password database terisi (Not Null),
            // TAPI user tidak mungkin bisa menebaknya untuk login lokal.
            // Mereka terpaksa login pakai kredensial AD/LDAP.
            $finalPassword = Str::random(32); 
        } else {
            // JIKA LOKAL (Bukan LDAP):
            // Kita wajibkan admin mengisi password.
            $request->validate([
                'password' => 'required|string|min:6',
            ]);
            // Simpan password plain text (Sesuai request kamu sebelumnya)
            $finalPassword = $request->password; 
        }

        // 3. Simpan ke Database
        $user = User::create([
            'empid' => $request->empid,
            'username' => $request->username,
            'is_ldap' => $isLdap ? 1 : 0, // Simpan status
            'password' => $finalPassword, // Random string (LDAP) atau Input (Lokal)
            'firstname' => $request->firstname,
            'middlename' => $request->middlename,
            'lastname' => $request->lastname,
            'slug' => $request->username . '-' . strtolower($request->firstname),
            'email_corp' => $request->email_corp,
            'email_personal' => $request->email_personal,
            'roleid' => 5, // Default: user standard
            'active' => 'y',
            'created_at' => now(),
        ]);

        // 4. Catat Log
        AuditLog::log(
            session('ams_user_id'),
            null,
            'user_created',
            'success',
            [
                'created_user_id' => $user->iduser, 
                'username' => $user->username,
                'type' => $isLdap ? 'LDAP User' : 'Local User'
            ]
        );

        $msgType = $isLdap ? 'User LDAP' : 'User Lokal';
        return redirect()->route('users.index')
            ->with('success', "$msgType berhasil ditambahkan.");
    }

    /**
     * Show edit user form
     */
    public function edit($id)
    {
        $user = User::findOrFail($id);
        return view('users.edit', compact('user'));
    }

    /**
     * Update user
     */
    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $request->validate([
            'empid' => 'required|string|max:10|unique:user,empid,' . $id . ',iduser',
            'username' => 'required|string|max:10|unique:user,username,' . $id . ',iduser',
            'firstname' => 'required|string|max:50',
            'middlename' => 'nullable|string|max:50',
            'lastname' => 'nullable|string|max:50',
            'email_corp' => 'nullable|email|max:50',
            'email_personal' => 'nullable|email|max:50',
            'active' => 'required|in:y,n',
            'is_ldap' => 'nullable|in:0,1'
        ]);

        // Update Data Dasar
        $user->update([
            'empid' => $request->empid,
            'username' => $request->username,
            'firstname' => $request->firstname,
            'middlename' => $request->middlename,
            'lastname' => $request->lastname,
            'email_corp' => $request->email_corp,
            'email_personal' => $request->email_personal,
            'active' => $request->active,
            // Jika ada perubahan tipe akun (LDAP <-> Lokal)
            'is_ldap' => $request->has('is_ldap') ? $request->is_ldap : 0,
            'updated_at' => now(),
        ]);

        // Logic Update Password (Opsional)
        // Hanya update password jika field diisi DAN user tersebut bukan LDAP (atau diubah jadi lokal)
        if ($request->filled('password') && $request->is_ldap == '0') {
            $user->update(['password' => $request->password]);
        }

        AuditLog::log(
            session('ams_user_id'),
            null,
            'user_updated',
            'success',
            ['updated_user_id' => $user->iduser, 'username' => $user->username]
        );

        return redirect()->route('users.index')
            ->with('success', 'User berhasil diupdate');
    }

    /**
     * Delete user (soft delete)
     */
    public function destroy($id)
    {
        $user = User::findOrFail($id);

        if ($user->iduser == session('ams_user_id')) {
            return back()->with('error', 'Anda tidak bisa menghapus akun sendiri');
        }

        $username = $user->username;
        $user->delete();

        AuditLog::log(
            session('ams_user_id'),
            null,
            'user_deleted',
            'success',
            ['deleted_user_id' => $id, 'username' => $username]
        );

        return redirect()->route('users.index')
            ->with('success', 'User berhasil dihapus');
    }
}