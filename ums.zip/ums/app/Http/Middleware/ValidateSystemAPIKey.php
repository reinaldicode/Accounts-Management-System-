<?php
// app/Http/Middleware/ValidateSystemAPIKey.php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\System;
use App\Models\AuditLog;
use Illuminate\Support\Facades\Log;

class ValidateSystemAPIKey
{
    /**
     * Validate that the request comes from a valid registered system
     * 
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // 1. Ambil header dari request
        $systemCode = $request->header('X-System-Code');
        $apiKey = $request->header('X-API-Key');

        // 2. Log incoming request untuk debugging
        Log::info('API Request Received', [
            'system_code' => $systemCode,
            'endpoint' => $request->path(),
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent()
        ]);

        // 3. Validasi header ada atau tidak
        if (!$systemCode || !$apiKey) {
            // Log unauthorized attempt
            AuditLog::log(null, null, 'api_unauthorized', 'failed', [
                'reason' => 'missing_credentials',
                'ip' => $request->ip(),
                'endpoint' => $request->path(),
                'user_agent' => $request->userAgent()
            ]);

            Log::warning('API Request Missing Credentials', [
                'ip' => $request->ip(),
                'endpoint' => $request->path()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'System authentication required. X-System-Code and X-API-Key headers are required.',
            ], 401);
        }

        // 4. Cari system berdasarkan code dan api_key
        $system = System::where('system_code', $systemCode)
            ->where('api_key', $apiKey)
            ->where('is_active', 1)
            ->first();

        // 5. Validasi system exists dan credentials cocok
        if (!$system) {
            // Log invalid credentials
            AuditLog::log(null, null, 'api_unauthorized', 'failed', [
                'system_code' => $systemCode,
                'reason' => 'invalid_credentials',
                'ip' => $request->ip(),
                'endpoint' => $request->path(),
                'user_agent' => $request->userAgent()
            ]);

            Log::warning('API Request Invalid Credentials', [
                'system_code' => $systemCode,
                'ip' => $request->ip(),
                'endpoint' => $request->path()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Invalid system credentials or system is inactive.',
            ], 401);
        }

        // 6. Inject system ke request untuk digunakan di controller
        $request->merge(['requesting_system' => $system]);

        // 7. Log successful API access
        AuditLog::log(null, $system->id, 'api_access', 'success', [
            'system_name' => $system->system_name,
            'endpoint' => $request->path(),
            'method' => $request->method(),
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent()
        ]);

        Log::info('API Request Authenticated', [
            'system_code' => $systemCode,
            'system_name' => $system->system_name,
            'endpoint' => $request->path()
        ]);

        return $next($request);
    }
}