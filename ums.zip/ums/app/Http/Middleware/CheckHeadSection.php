<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckHeadSection
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = session('ams_user'); // Get user from session

        if (!$user) {
            return redirect()->route('login');
        }

        // DEFINISI "HEAD SECTION":
        // 1. Role ID tertentu (misal: 3=Manager, 4=Head)
        // 2. ATAU punya akses level 'Admin' di Section tersebut
        
        $isHeadRole = in_array($user->roleid, [3, 4]); // Sesuaikan ID Role Manager/Head di DB Anda
        
        // Jika Anda ingin check via UserSystemAccess (state='Admin'):
        // $hasAdminState = $user->systemAccess()->where('is_active', 1)->whereJsonContains('access_metadata->state', 'Admin')->exists();

        if ($isHeadRole) {
            return $next($request);
        }

        abort(403, 'Unauthorized. Area khusus Head Section.');
    }
}