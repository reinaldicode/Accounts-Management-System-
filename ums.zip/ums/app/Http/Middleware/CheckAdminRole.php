<?php
// app/Http/Middleware/CheckAdminRole.php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\AuditLog;

class CheckAdminRole
{
    /**
     * Handle an incoming request.
     * 
     * Hanya Super Admin (0), Admin (1), Manager (2) yang bisa akses dashboard
     */
    public function handle(Request $request, Closure $next)
    {
        $user = session('ams_user');
        
        if (!$user) {
            return redirect()->route('login');
        }
        
        // Define admin roles
        $adminRoles = [0, 1, 2]; // Super Admin, Admin, Manager
        
        // Check if user has admin role
        if (!in_array($user->roleid, $adminRoles)) {
            AuditLog::log(
                $user->iduser,
                null,
                'dashboard_access_denied',
                'denied',
                ['reason' => 'insufficient_privileges']
            );
            
            // Redirect regular user ke system selection page
            return redirect()->route('systems.selection')
                ->with('error', 'You do not have permission to access the admin dashboard');
        }
        
        return $next($request);
    }
}