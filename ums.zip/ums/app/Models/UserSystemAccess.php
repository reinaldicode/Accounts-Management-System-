<?php
// app/Models/UserSystemAccess.php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserSystemAccess extends Model
{
    protected $table = 'user_system_access';
    public $timestamps = true;

    protected $fillable = [
        'user_id',
        'system_id',
        'role_id',
        'is_active',
        'granted_at',
        'granted_by',
        'expires_at',
        'access_metadata',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'granted_at' => 'datetime',
        'expires_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'access_metadata' => 'array', // ✅ Auto convert JSON <-> Array
    ];

    /**
     * Relationships
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'iduser');
    }

    public function system()
    {
        return $this->belongsTo(System::class, 'system_id', 'id');
    }

    public function role()
    {
        return $this->belongsTo(Role::class, 'role_id', 'id');
    }

    public function grantedBy()
    {
        return $this->belongsTo(User::class, 'granted_by', 'iduser');
    }

    /**
     * Status Helpers
     */
    public function isActive()
    {
        if (!$this->is_active) return false;
        if ($this->expires_at && $this->expires_at->isPast()) return false;
        return true;
    }

    public function hasExpired()
    {
        return $this->expires_at && $this->expires_at->isPast();
    }

    /**
     * ========================================
     * ENHANCED: Access Metadata Helpers
     * ========================================
     * Easy access to Section, State, Level, Groups
     */

    /**
     * Get section from metadata
     * @return string
     */
    public function getSection()
    {
        return $this->access_metadata['section'] ?? 'Unknown';
    }

    /**
     * Get department from metadata
     * @return string|null
     */
    public function getDepartment()
    {
        return $this->access_metadata['department'] ?? null;
    }

    /**
     * Get state (Approver, Originator, Admin, etc)
     * @return string
     */
    public function getState()
    {
        return $this->access_metadata['state'] ?? 'Originator';
    }

    /**
     * Get level (1-10)
     * @return int
     */
    public function getLevel()
    {
        return $this->access_metadata['level'] ?? 0;
    }

    /**
     * Get groups array
     * @return array
     */
    public function getGroups()
    {
        return $this->access_metadata['groups'] ?? [];
    }

    /**
     * Check if user belongs to a specific group
     * @param string $groupName
     * @return bool
     */
    public function hasGroup($groupName)
    {
        $groups = $this->getGroups();
        return in_array($groupName, $groups);
    }

    /**
     * Check if user has any of the given groups
     * @param array $groupNames
     * @return bool
     */
    public function hasAnyGroup(array $groupNames)
    {
        $userGroups = $this->getGroups();
        return !empty(array_intersect($groupNames, $userGroups));
    }

    /**
     * Check if user has all of the given groups
     * @param array $groupNames
     * @return bool
     */
    public function hasAllGroups(array $groupNames)
    {
        $userGroups = $this->getGroups();
        return empty(array_diff($groupNames, $userGroups));
    }

    /**
     * Get custom permissions
     * @return array
     */
    public function getCustomPermissions()
    {
        return $this->access_metadata['custom_permissions'] ?? [];
    }

    /**
     * Check if user has specific custom permission
     * @param string $permission
     * @return bool
     */
    public function hasCustomPermission($permission)
    {
        $permissions = $this->getCustomPermissions();
        return isset($permissions[$permission]) && $permissions[$permission] === true;
    }

    /**
     * Update metadata (helper untuk menambah/update field)
     * @param array $data
     * @return bool
     */
    public function updateMetadata(array $data)
    {
        $metadata = $this->access_metadata ?? [];
        $metadata = array_merge($metadata, $data);
        
        return $this->update(['access_metadata' => $metadata]);
    }

    /**
     * Add group to user
     * @param string $groupName
     * @return bool
     */
    public function addGroup($groupName)
    {
        $groups = $this->getGroups();
        
        if (!in_array($groupName, $groups)) {
            $groups[] = $groupName;
            return $this->updateMetadata(['groups' => $groups]);
        }
        
        return false; // Already has this group
    }

    /**
     * Remove group from user
     * @param string $groupName
     * @return bool
     */
    public function removeGroup($groupName)
    {
        $groups = $this->getGroups();
        $index = array_search($groupName, $groups);
        
        if ($index !== false) {
            unset($groups[$index]);
            $groups = array_values($groups); // Re-index array
            return $this->updateMetadata(['groups' => $groups]);
        }
        
        return false; // Group not found
    }

    /**
     * Check if user is Approver
     * @return bool
     */
    public function isApprover()
    {
        return strtolower($this->getState()) === 'approver';
    }

    /**
     * Check if user is Originator
     * @return bool
     */
    public function isOriginator()
    {
        return strtolower($this->getState()) === 'originator';
    }

    /**
     * Check if user is Admin
     * @return bool
     */
    public function isAdmin()
    {
        return strtolower($this->getState()) === 'admin';
    }

    /**
     * Get complete access information (for debugging/logging)
     * @return array
     */
    public function getAccessInfo()
    {
        return [
            'user_id' => $this->user_id,
            'system' => $this->system->system_name ?? 'Unknown',
            'role' => $this->role->name ?? 'Unknown',
            'section' => $this->getSection(),
            'department' => $this->getDepartment(),
            'state' => $this->getState(),
            'level' => $this->getLevel(),
            'groups' => $this->getGroups(),
            'is_active' => $this->isActive(),
            'expires_at' => $this->expires_at?->toDateTimeString(),
        ];
    }

    /**
     * Scope: Get all active access
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', 1)
                     ->where(function($q) {
                         $q->whereNull('expires_at')
                           ->orWhere('expires_at', '>', now());
                     });
    }

    /**
     * Scope: Get access by section
     */
    public function scopeBySection($query, $section)
    {
        return $query->whereJsonContains('access_metadata->section', $section);
    }

    /**
     * Scope: Get access by state
     */
    public function scopeByState($query, $state)
    {
        return $query->whereJsonContains('access_metadata->state', $state);
    }

    /**
     * Scope: Get access by group
     */
    public function scopeByGroup($query, $groupName)
    {
        return $query->whereJsonContains('access_metadata->groups', $groupName);
    }
}