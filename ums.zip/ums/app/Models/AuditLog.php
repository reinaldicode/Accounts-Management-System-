<?php
// app/Models/AuditLog.php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Request; // ✅ ADD THIS

class AuditLog extends Model
{
    protected $table = 'audit_logs';
    
    protected $fillable = [
        'user_id',
        'system_id',
        'action',
        'ip_address',
        'user_agent',
        'status',
        'additional_data',
    ];
    
    protected $casts = [
        'additional_data' => 'array',
        'created_at' => 'datetime',
    ];
    
    const UPDATED_AT = null;
    
    // ============================================
    // RELATIONSHIPS
    // ============================================
    
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'iduser');
    }
    
    public function system()
    {
        return $this->belongsTo(System::class);
    }
    
    // ============================================
    // STATIC HELPER: Log Action
    // ============================================
    
    /**
     * Quick log helper
     */
    public static function log($userId, $systemId, $action, $status, $additionalData = null)
    {
        return self::create([
            'user_id' => $userId,
            'system_id' => $systemId,
            'action' => $action,
            'status' => $status,
            'ip_address' => Request::ip(),      // ✅ CHANGED
            'user_agent' => Request::userAgent(), // ✅ CHANGED
            'additional_data' => $additionalData,
        ]);
    }
    
    // ============================================
    // SCOPES
    // ============================================
    
    public function scopeAction($query, $action)
    {
        return $query->where('action', $action);
    }
    
    public function scopeStatus($query, $status)
    {
        return $query->where('status', $status);
    }
    
    public function scopeToday($query)
    {
        return $query->whereDate('created_at', today());
    }
    
    public function scopeDateRange($query, $from, $to)
    {
        return $query->whereBetween('created_at', [$from, $to]);
    }
    
    public function scopeSuccessful($query)
    {
        return $query->where('status', 'success');
    }
    
    public function scopeFailed($query)
    {
        return $query->where('status', 'failed');
    }
    
    // ============================================
    // HELPER METHODS
    // ============================================
    
    public function isLoginAction()
    {
        return in_array($this->action, [
            'login_success',
            'login_failed',
            'login_failed_wrong_password',
            'login_failed_locked',
            'login_failed_inactive'
        ]);
    }
    
    public function isAccessAction()
    {
        return in_array($this->action, [
            'access_granted',
            'access_revoked',
            'access_updated'
        ]);
    }
    
    public function isApiAction()
    {
        return $this->action === 'api_access';
    }
    
    public function getFormattedAction()
    {
        return str_replace('_', ' ', ucwords($this->action));
    }
}