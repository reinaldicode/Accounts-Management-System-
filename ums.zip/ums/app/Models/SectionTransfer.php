<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SectionTransfer extends Model
{
    protected $table = 'section_transfers';
    
    protected $fillable = [
        'user_id', 'from_section', 'to_section', 'status',
        'approved_by_exit', 'exit_approved_at',
        'approved_by_entry', 'entry_approved_at',
        'remarks'
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'iduser');
    }

    // Helper to check if current user can approve
    public function canApproveExit($userSection)
    {
        return $this->status === 'pending_exit' && $this->from_section === $userSection;
    }

    public function canApproveEntry($userSection)
    {
        return $this->status === 'pending_entry' && $this->to_section === $userSection;
    }
}