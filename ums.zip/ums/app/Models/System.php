<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;

class System extends Model
{
    protected $table = 'systems';
    public $timestamps = true;

    protected $fillable = [
        'system_code',
        'system_name',
        'system_url',
        'api_key',
        'permission_template',
        'description',
        'is_active',
    ];

    protected $casts = [
        'permission_template' => 'array',
        'is_active' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    // Relationships
    public function userAccess()
    {
        return $this->hasMany(UserSystemAccess::class, 'system_id');
    }

    public function auditLogs()
    {
        return $this->hasMany(AuditLog::class, 'system_id');
    }

    // Helper methods
    public function isActive()
    {
        return $this->is_active === true;
    }

    public function validateApiKey($apiKey)
    {
        return $this->api_key === $apiKey;
    }

    /**
     * ✅ NEW: Get permission template as array
     * Handles both string (JSON) and array format
     */
    public function getPermissionTemplate()
    {
        $template = $this->permission_template;
        
        // Jika sudah array (dari cast), return as is
        if (is_array($template)) {
            return $template;
        }
        
        // Jika string, decode
        if (is_string($template)) {
            $decoded = json_decode($template, true);
            return $decoded ?? [];
        }
        
        return [];
    }

    /**
     * ✅ FIXED: Get groups list from permission_template
     * Returns array of group names: ["Administrasi", "QA", ...]
     * 
     * Handles multiple JSON structures:
     * 1. New format: {"groups": [{"name": "...", "description": "..."}, ...]}
     * 2. Old format: {"fields": [...], "groups": [...]}
     */
    public function getGroups()
    {
        try {
            $template = $this->getPermissionTemplate();
            
            Log::info('🔍 Getting groups - Full template structure', [
                'system_id' => $this->id,
                'system_code' => $this->system_code,
                'template' => $template,
                'template_keys' => is_array($template) ? array_keys($template) : 'not_array'
            ]);
            
            // ✅ FIX 1: Check if template is valid
            if (!is_array($template) || empty($template)) {
                Log::warning('Template is not an array or empty', [
                    'system_id' => $this->id,
                    'template_type' => gettype($template)
                ]);
                return [];
            }
            
            // ✅ FIX 2: Try to find 'groups' key at root level
            if (isset($template['groups']) && is_array($template['groups'])) {
                
                // Check if groups is array of objects with 'name' key
                $groups = collect($template['groups'])
                    ->map(function($group) {
                        // Handle both object format and string format
                        if (is_array($group) && isset($group['name'])) {
                            return $group['name'];
                        }
                        return is_string($group) ? $group : null;
                    })
                    ->filter()
                    ->values()
                    ->toArray();
                
                Log::info('✅ Groups extracted successfully', [
                    'system_id' => $this->id,
                    'system_code' => $this->system_code,
                    'groups_count' => count($groups),
                    'groups' => $groups
                ]);
                
                return $groups;
            }
            
            Log::warning('❌ No groups key found in template', [
                'system_id' => $this->id,
                'system_code' => $this->system_code,
                'available_keys' => array_keys($template)
            ]);
            
            return [];
            
        } catch (\Exception $e) {
            Log::error('Error getting groups from system', [
                'system_id' => $this->id,
                'system_code' => $this->system_code,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return [];
        }
    }

    /**
     * ✅ NEW: Get full group details (with description, created_at, etc)
     * Returns array of group objects
     */
    public function getGroupsDetailed()
    {
        try {
            $template = $this->getPermissionTemplate();
            
            if (!isset($template['groups']) || !is_array($template['groups'])) {
                return [];
            }
            
            return $template['groups'];
            
        } catch (\Exception $e) {
            Log::error('Error getting detailed groups', [
                'system_id' => $this->id,
                'error' => $e->getMessage()
            ]);
            return [];
        }
    }

    /**
     * ✅ NEW: Check if a group exists
     */
    public function hasGroup($groupName)
    {
        $groups = $this->getGroups();
        return in_array($groupName, $groups);
    }

    /**
     * ✅ NEW: Add a new group to permission_template
     */
    public function addGroup($groupName, $description = null, $createdBy = null)
    {
        try {
            $template = $this->getPermissionTemplate();
            
            // Initialize groups array if not exists
            if (!isset($template['groups'])) {
                $template['groups'] = [];
            }
            
            // Check if group already exists
            foreach ($template['groups'] as $group) {
                if ($group['name'] === $groupName) {
                    return false; // Group already exists
                }
            }
            
            // Add new group
            $template['groups'][] = [
                'name' => $groupName,
                'description' => $description,
                'created_at' => now()->toDateTimeString(),
                'created_by' => $createdBy ?? 'system',
                'updated_at' => now()->toDateTimeString()
            ];
            
            // Save
            $this->permission_template = $template;
            $this->save();
            
            Log::info('Group added successfully', [
                'system_id' => $this->id,
                'group_name' => $groupName
            ]);
            
            return true;
            
        } catch (\Exception $e) {
            Log::error('Error adding group', [
                'system_id' => $this->id,
                'group_name' => $groupName,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * ✅ NEW: Update a group
     */
    public function updateGroup($index, $newName, $newDescription = null)
    {
        try {
            $template = $this->getPermissionTemplate();
            
            if (!isset($template['groups'][$index])) {
                return false;
            }
            
            $template['groups'][$index]['name'] = $newName;
            $template['groups'][$index]['description'] = $newDescription;
            $template['groups'][$index]['updated_at'] = now()->toDateTimeString();
            
            $this->permission_template = $template;
            $this->save();
            
            Log::info('Group updated successfully', [
                'system_id' => $this->id,
                'group_index' => $index,
                'new_name' => $newName
            ]);
            
            return true;
            
        } catch (\Exception $e) {
            Log::error('Error updating group', [
                'system_id' => $this->id,
                'group_index' => $index,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * ✅ NEW: Delete a group
     */
    public function deleteGroup($index)
    {
        try {
            $template = $this->getPermissionTemplate();
            
            if (!isset($template['groups'][$index])) {
                return false;
            }
            
            // Remove group
            array_splice($template['groups'], $index, 1);
            
            $this->permission_template = $template;
            $this->save();
            
            Log::info('Group deleted successfully', [
                'system_id' => $this->id,
                'group_index' => $index
            ]);
            
            return true;
            
        } catch (\Exception $e) {
            Log::error('Error deleting group', [
                'system_id' => $this->id,
                'group_index' => $index,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }
}