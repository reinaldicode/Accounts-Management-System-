

<?php $__env->startSection('title', 'Audit Log'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    
    <div class="bg-gradient-to-r from-gray-900 to-gray-700 rounded-xl shadow-lg p-6 text-white">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-3xl font-bold flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                    Audit Log
                </h1>
                <p class="mt-2 text-gray-300">Monitor all system activities and security events</p>
            </div>
            <a href="<?php echo e(route('audit.export', Request::all())); ?>" 
               class="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                Export CSV
            </a>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div class="bg-white rounded-lg shadow p-4 border-l-4 border-blue-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-600">Today's Events</p>
                    <p class="text-2xl font-bold text-gray-900"><?php echo e($stats['today'] ?? 0); ?></p>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-blue-500 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow p-4 border-l-4 border-green-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-600">Login Success</p>
                    <p class="text-2xl font-bold text-green-600"><?php echo e($stats['login_success'] ?? 0); ?></p>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-green-500 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow p-4 border-l-4 border-red-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-600">Login Failed</p>
                    <p class="text-2xl font-bold text-red-600"><?php echo e($stats['login_failed'] ?? 0); ?></p>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-red-500 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow p-4 border-l-4 border-indigo-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-600">API Calls</p>
                    <p class="text-2xl font-bold text-indigo-600"><?php echo e($stats['api_access'] ?? 0); ?></p>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-indigo-500 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow p-4 border-l-4 border-purple-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-600">Access Changes</p>
                    <p class="text-2xl font-bold text-purple-600"><?php echo e($stats['access_changes'] ?? 0); ?></p>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-purple-500 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                </svg>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow p-6">
        <form method="GET" class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-6 gap-4">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Action Type</label>
                    <select name="action" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500">
                        <option value="">All Actions</option>
                        <option value="login_success" <?php echo e(Request::get('action') == 'login_success' ? 'selected' : ''); ?>>Login Success</option>
                        <option value="login_failed" <?php echo e(Request::get('action') == 'login_failed' ? 'selected' : ''); ?>>Login Failed</option>
                        <option value="logout" <?php echo e(Request::get('action') == 'logout' ? 'selected' : ''); ?>>Logout</option>
                        <option value="access_granted" <?php echo e(Request::get('action') == 'access_granted' ? 'selected' : ''); ?>>Access Granted</option>
                        <option value="api_access" <?php echo e(Request::get('action') == 'api_access' ? 'selected' : ''); ?>>API Access</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                    <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500">
                        <option value="">All Status</option>
                        <option value="success" <?php echo e(Request::get('status') == 'success' ? 'selected' : ''); ?>>Success</option>
                        <option value="failed" <?php echo e(Request::get('status') == 'failed' ? 'selected' : ''); ?>>Failed</option>
                        <option value="denied" <?php echo e(Request::get('status') == 'denied' ? 'selected' : ''); ?>>Denied</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">User</label>
                    <input type="text" name="user" value="<?php echo e(Request::get('user')); ?>" placeholder="Search user..."
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">IP Address</label>
                    <input type="text" name="ip" value="<?php echo e(Request::get('ip')); ?>" placeholder="IP address..."
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Date From</label>
                    <input type="date" name="date_from" value="<?php echo e(Request::get('date_from')); ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Date To</label>
                    <input type="date" name="date_to" value="<?php echo e(Request::get('date_to')); ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500">
                </div>
            </div>
            
            <div class="flex justify-end space-x-2">
                <button type="submit" class="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                    Search
                </button>
                <?php if(Request::hasAny(['action', 'status', 'user', 'ip', 'date_from', 'date_to'])): ?>
                <a href="<?php echo e(route('audit.index')); ?>" class="px-6 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                    Reset
                </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <div class="bg-white rounded-xl shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 border-b">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Timestamp</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">IP Address</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">System</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Details</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-3 whitespace-nowrap text-xs text-gray-900">
                            <?php echo e($log->created_at->format('d M Y H:i:s')); ?>

                        </td>
                        <td class="px-4 py-3 whitespace-nowrap">
                            <?php if($log->user): ?>
                            <div class="flex items-center">
                                <div class="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center mr-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                    </svg>
                                </div>
                                <div>
                                    <div class="text-xs font-medium text-gray-900"><?php echo e($log->user->firstname); ?></div>
                                    <div class="text-xs text-gray-500"><?php echo e($log->user->username); ?></div>
                                </div>
                            </div>
                            <?php else: ?>
                            <span class="text-xs text-gray-400">System</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 whitespace-nowrap">
                            <span class="text-xs font-medium text-gray-700">
                                <?php echo e(str_replace('_', ' ', ucwords($log->action))); ?>

                            </span>
                        </td>
                        <td class="px-4 py-3 whitespace-nowrap">
                            <?php if($log->status === 'success'): ?>
                            <span class="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800 inline-flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                Success
                            </span>
                            <?php elseif($log->status === 'failed'): ?>
                            <span class="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800 inline-flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                Failed
                            </span>
                            <?php else: ?>
                            <span class="px-2 py-1 text-xs font-semibold rounded-full bg-orange-100 text-orange-800 inline-flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                                </svg>
                                Denied
                            </span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 whitespace-nowrap text-xs text-gray-500 font-mono">
                            <?php echo e($log->ip_address ?? '-'); ?>

                        </td>
                        <td class="px-4 py-3 whitespace-nowrap text-xs">
                            <?php if($log->system): ?>
                            <span class="text-indigo-600 font-medium"><?php echo e($log->system->system_code); ?></span>
                            <?php else: ?>
                            <span class="text-gray-400">-</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3">
                            <?php if($log->additional_data): ?>
                            <button onclick="showDetails(<?php echo e($log->id); ?>)" 
                                    class="text-indigo-600 hover:text-indigo-900 text-xs font-medium inline-flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                View
                            </button>
                            <?php else: ?>
                            <span class="text-xs text-gray-400">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="px-6 py-12 text-center text-gray-500">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-24 w-24 mx-auto mb-4 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
                            </svg>
                            <p>No audit logs found</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($logs->hasPages()): ?>
        <div class="px-6 py-4 border-t bg-gray-50">
            <?php echo e($logs->appends(Request::all())->links()); ?>

        </div>
        <?php endif; ?>
    </div>

</div>

<!-- Details Modal -->
<div id="detailsModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl shadow-2xl max-w-3xl w-full mx-4 max-h-[85vh] overflow-hidden">
        <div class="flex items-center justify-between p-6 border-b bg-gray-50">
            <h3 class="text-xl font-bold text-gray-900 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-indigo-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                Log Details
            </h3>
            <button onclick="closeDetails()" class="text-gray-400 hover:text-gray-600 text-2xl">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        <div id="detailsContent" class="p-6 overflow-y-auto max-h-[70vh]">
            <!-- Content loaded via JS -->
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function showDetails(logId) {
    document.getElementById('detailsModal').classList.remove('hidden');
    document.getElementById('detailsContent').innerHTML = '<div class="text-center py-8"><svg xmlns="http://www.w3.org/2000/svg" class="animate-spin h-12 w-12 text-indigo-600 mx-auto" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg><p class="text-gray-600 mt-4">Loading...</p></div>';
    
    fetch('/ums/audit/' + logId)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const log = data.log;
                let html = '<div class="space-y-4">';
                
                // Basic Info Section
                html += '<div class="bg-gray-50 rounded-lg p-4">';
                html += '<h4 class="font-bold text-gray-800 mb-3 flex items-center"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-indigo-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>Basic Information</h4>';
                html += '<div class="grid grid-cols-2 gap-3 text-sm">';
                html += '<div><span class="text-gray-600">Action:</span> <span class="font-medium text-gray-900">' + log.action.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) + '</span></div>';
                html += '<div><span class="text-gray-600">Status:</span> <span class="font-medium text-gray-900">' + log.status.toUpperCase() + '</span></div>';
                html += '<div><span class="text-gray-600">Timestamp:</span> <span class="font-medium text-gray-900">' + log.created_at + '</span></div>';
                html += '<div><span class="text-gray-600">IP Address:</span> <span class="font-medium font-mono text-gray-900">' + (log.ip_address || '-') + '</span></div>';
                
                if (log.user) {
                    html += '<div class="col-span-2"><span class="text-gray-600">User:</span> <span class="font-medium text-gray-900">' + log.user.name + ' (' + log.user.username + ')</span></div>';
                }
                
                if (log.system) {
                    html += '<div class="col-span-2"><span class="text-gray-600">System:</span> <span class="font-medium text-gray-900">' + log.system.name + ' (' + log.system.code + ')</span></div>';
                }
                
                html += '</div></div>';
                
                // Additional Data Section (User Friendly)
                if (log.additional_data && Object.keys(log.additional_data).length > 0) {
                    html += '<div class="bg-blue-50 rounded-lg p-4">';
                    html += '<h4 class="font-bold text-gray-800 mb-3 flex items-center"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-blue-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" /></svg>Additional Details</h4>';
                    html += '<div class="space-y-2">';
                    
                    const data = log.additional_data;
                    
                    for (const [key, value] of Object.entries(data)) {
                        html += '<div class="flex items-start space-x-3 text-sm">';
                        html += '<span class="text-gray-600 font-medium min-w-[140px]">' + key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) + ':</span>';
                        
                        if (typeof value === 'object' && value !== null) {
                            html += '<div class="flex-1">';
                            html += '<pre class="text-xs bg-white p-3 rounded border border-gray-200 overflow-x-auto">' + JSON.stringify(value, null, 2) + '</pre>';
                            html += '</div>';
                        } else {
                            html += '<span class="flex-1 font-mono text-gray-900 bg-white px-2 py-1 rounded">' + (value || '-') + '</span>';
                        }
                        
                        html += '</div>';
                    }
                    
                    html += '</div></div>';
                }
                
                // User Agent Section
                if (log.user_agent) {
                    html += '<div class="bg-gray-50 rounded-lg p-4">';
                    html += '<h4 class="font-bold text-gray-800 mb-2 flex items-center"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>User Agent</h4>';
                    html += '<p class="text-xs font-mono text-gray-700 break-all bg-white p-3 rounded border border-gray-200">' + log.user_agent + '</p>';
                    html += '</div>';
                }
                
                html += '</div>';
                
                document.getElementById('detailsContent').innerHTML = html;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('detailsContent').innerHTML = '<div class="text-center py-8"><svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-red-500 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg><p class="text-red-600 mt-4">Error loading details. Please try again.</p></div>';
        });
}

function closeDetails() {
    document.getElementById('detailsModal').classList.add('hidden');
}

document.getElementById('detailsModal').addEventListener('click', function(e) {
    if (e.target === this) closeDetails();
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeDetails();
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/ums/resources/views/audit/index.blade.php ENDPATH**/ ?>