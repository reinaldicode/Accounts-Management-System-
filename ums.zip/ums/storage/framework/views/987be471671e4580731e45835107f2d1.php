<!-- resources/views/systems/selection.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Select System - UMS Portal</title>
    
    <script src="<?php echo e(asset('assets/vendor/tailwind.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fontawesome.css')); ?>">
</head>
<body class="bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 min-h-screen">
    
    <div class="container mx-auto px-4 py-8">
        
        <!-- Header Section -->
        <div class="bg-white rounded-2xl shadow-2xl p-6 mb-6">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-2xl font-bold text-gray-800">
                        👋 Welcome, <?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?>

                    </h2>
                    <p class="text-gray-600 mt-1"><?php echo e($user->email_corp); ?></p>
                </div>
                <div>
                    <a href="<?php echo e(route('logout')); ?>" 
                       class="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg transition duration-200 inline-flex items-center">
                        <i class="fas fa-sign-out-alt mr-2"></i>
                        Logout
                    </a>
                </div>
            </div>
        </div>

        <!-- Systems Section -->
        <div class="mb-4">
            <h3 class="text-white text-xl font-semibold mb-4">
                <i class="fas fa-th-large mr-2"></i>
                Your Systems (<?php echo e(count($userSystems)); ?>)
            </h3>
        </div>
        
        <?php if(count($userSystems) > 0): ?>
            <!-- Systems Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $userSystems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $access): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('systems.access', $access->system_id)); ?>" 
                   class="bg-white rounded-2xl shadow-2xl p-6 hover:shadow-3xl transform hover:-translate-y-2 transition duration-300">
                    
                    <!-- System Icon -->
                    <div class="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center mb-4">
                        <?php
                            $icons = [
                                'docoline' => 'fa-file-alt',
                                'hrms' => 'fa-users',
                                'erp' => 'fa-chart-line',
                                'inventory' => 'fa-boxes',
                                'finance' => 'fa-money-bill-wave',
                                'procurement' => 'fa-shopping-cart',
                                'sales' => 'fa-handshake',
                                'production' => 'fa-industry',
                                'quality' => 'fa-check-circle',
                                'maintenance' => 'fa-tools',
                                'warehouse' => 'fa-warehouse',
                                'logistics' => 'fa-truck'
                            ];
                            $icon = $icons[$access->system->system_code] ?? 'fa-desktop';
                        ?>
                        <i class="fas <?php echo e($icon); ?> text-3xl text-white"></i>
                    </div>
                    
                    <!-- System Name -->
                    <h3 class="text-xl font-bold text-gray-800 mb-2">
                        <?php echo e($access->system->system_name); ?>

                    </h3>
                    
                    <!-- System Description -->
                    <p class="text-gray-600 text-sm mb-4">
                        <?php echo e($access->system->description); ?>

                    </p>
                    
                    <!-- Role Badge -->
                    <div class="mb-3">
                        <span class="inline-block bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-xs font-medium">
                            <i class="fas fa-user-tag mr-1"></i>
                            <?php echo e($access->role->name); ?>

                        </span>
                    </div>
                    
                    <!-- Permissions (if exists) -->
                    <?php if($access->access_metadata): ?>
                    <div class="pt-3 border-t border-gray-200 flex flex-wrap gap-2">
                        <?php if(isset($access->access_metadata['section'])): ?>
                            <span class="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs">
                                <i class="fas fa-building mr-1"></i>
                                <?php echo e($access->access_metadata['section']); ?>

                            </span>
                        <?php endif; ?>
                        
                        <?php if(isset($access->access_metadata['state'])): ?>
                            <span class="bg-green-50 text-green-700 px-2 py-1 rounded text-xs">
                                <i class="fas fa-id-badge mr-1"></i>
                                <?php echo e($access->access_metadata['state']); ?>

                            </span>
                        <?php endif; ?>
                        
                        <?php if(isset($access->access_metadata['level'])): ?>
                            <span class="bg-purple-50 text-purple-700 px-2 py-1 rounded text-xs">
                                <i class="fas fa-layer-group mr-1"></i>
                                Level <?php echo e($access->access_metadata['level']); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <!-- No Access Card -->
            <div class="bg-white rounded-2xl shadow-2xl p-12 text-center">
                <div class="text-gray-300 mb-6">
                    <i class="fas fa-lock text-8xl"></i>
                </div>
                <h3 class="text-2xl font-bold text-gray-800 mb-3">No System Access</h3>
                <p class="text-gray-600 mb-2">You don't have access to any systems yet.</p>
                <p class="text-gray-500 text-sm">Please contact your administrator to request access.</p>
            </div>
        <?php endif; ?>
        
    </div>
    
</body>
</html><?php /**PATH /var/www/ums/resources/views/systems/selection.blade.php ENDPATH**/ ?>