<!-- resources/views/layouts/sidebar.blade.php (ROMBAK TOTAL PAKAI VANILLA JS) -->

<!-- Overlay untuk Mobile -->
<div id="sidebar-overlay" class="fixed inset-0 bg-gray-900 bg-opacity-50 z-10 lg:hidden hidden"></div>

<!-- Sidebar -->
<aside id="app-sidebar" class="fixed left-0 top-16 h-[calc(100vh-4rem)] w-64 z-20 glass-effect border-r border-blue-200 shadow-lg transition-transform duration-300 lg:translate-x-0">
    
    <div class="p-4 h-full overflow-y-auto">
        <nav class="space-y-1">
            
            <!-- Dashboard -->
            <a href="<?php echo e(route('dashboard')); ?>" 
               class="flex items-center space-x-3 px-4 py-3 rounded-xl group <?php echo e(request()->routeIs('dashboard*') ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg' : 'text-gray-700 hover:bg-blue-50'); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 <?php echo e(request()->routeIs('dashboard*') ? 'text-white' : 'text-blue-500'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
                <span class="font-medium text-sm">Dashboard</span>
                <?php if(request()->routeIs('dashboard*')): ?>
                <div class="ml-auto">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-2 w-2 text-white" fill="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="12"/>
                    </svg>
                </div>
                <?php endif; ?>
            </a>
            
            <!-- Divider -->
            <div class="py-2">
                <p class="text-xs font-semibold text-gray-400 uppercase tracking-wider px-4">Management</p>
            </div>
            
            <!-- User Management -->
            <a href="<?php echo e(route('users.index')); ?>" 
               class="flex items-center space-x-3 px-4 py-3 rounded-xl group <?php echo e(request()->routeIs('users*') ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg' : 'text-gray-700 hover:bg-blue-50'); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 <?php echo e(request()->routeIs('users*') ? 'text-white' : 'text-blue-500'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
                <span class="font-medium text-sm">Users</span>
                <?php if(request()->routeIs('users*')): ?>
                <div class="ml-auto">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-2 w-2 text-white" fill="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="12"/>
                    </svg>
                </div>
                <?php endif; ?>
            </a>
            
            <!-- System Management -->
            <a href="<?php echo e(route('systems.index')); ?>" 
               class="flex items-center space-x-3 px-4 py-3 rounded-xl group <?php echo e(request()->routeIs('systems*') ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg' : 'text-gray-700 hover:bg-blue-50'); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 <?php echo e(request()->routeIs('systems*') ? 'text-white' : 'text-blue-500'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" />
                </svg>
                <span class="font-medium text-sm">Systems</span>
                <?php if(request()->routeIs('systems*')): ?>
                <div class="ml-auto">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-2 w-2 text-white" fill="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="12"/>
                    </svg>
                </div>
                <?php endif; ?>
            </a>
            
            <!-- Role Management -->
            <a href="<?php echo e(route('roles.index')); ?>" 
               class="flex items-center space-x-3 px-4 py-3 rounded-xl group <?php echo e(request()->routeIs('roles*') ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg' : 'text-gray-700 hover:bg-blue-50'); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 <?php echo e(request()->routeIs('roles*') ? 'text-white' : 'text-blue-500'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                </svg>
                <span class="font-medium text-sm">Roles</span>
                <?php if(request()->routeIs('roles*')): ?>
                <div class="ml-auto">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-2 w-2 text-white" fill="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="12"/>
                    </svg>
                </div>
                <?php endif; ?>
            </a>
            
            <!-- Access Management -->
            <a href="<?php echo e(route('access.index')); ?>" 
               class="flex items-center space-x-3 px-4 py-3 rounded-xl group <?php echo e(request()->routeIs('access*') ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg' : 'text-gray-700 hover:bg-blue-50'); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 <?php echo e(request()->routeIs('access*') ? 'text-white' : 'text-blue-500'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                </svg>
                <span class="font-medium text-sm">User Access</span>
                <?php if(request()->routeIs('access*')): ?>
                <div class="ml-auto">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-2 w-2 text-white" fill="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="12"/>
                    </svg>
                </div>
                <?php endif; ?>
            </a>
            
            <!-- Divider -->
            <div class="py-2">
                <p class="text-xs font-semibold text-gray-400 uppercase tracking-wider px-4">Security</p>
            </div>
            
            <!-- Audit Trail -->
            <a href="<?php echo e(route('audit.index')); ?>" 
               class="flex items-center space-x-3 px-4 py-3 rounded-xl group <?php echo e(request()->routeIs('audit*') ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg' : 'text-gray-700 hover:bg-blue-50'); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 <?php echo e(request()->routeIs('audit*') ? 'text-white' : 'text-blue-500'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
                <span class="font-medium text-sm">Audit Log</span>
                <?php if(request()->routeIs('audit*')): ?>
                <div class="ml-auto">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-2 w-2 text-white" fill="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="12"/>
                    </svg>
                </div>
                <?php endif; ?>
            </a>
            
        </nav>
        
        <!-- Footer Info -->
        <div class="absolute bottom-4 left-4 right-4">
            <div class="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-xl p-4">
                <div class="flex items-center space-x-3 mb-2">
                    <div class="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>
                    <div>
                        <p class="text-xs font-semibold text-gray-800">Need Help?</p>
                        <p class="text-xs text-gray-600">Contact support</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</aside>

<style>
    /* Sidebar hidden state - WORKS ON DESKTOP TOO */
    #app-sidebar.sidebar-hidden {
        transform: translateX(-100%);
    }
</style><?php /**PATH /var/www/ums/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>