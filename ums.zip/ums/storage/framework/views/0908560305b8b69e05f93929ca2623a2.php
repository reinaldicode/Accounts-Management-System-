<!-- resources/views/access/create.blade.php -->



<?php $__env->startSection('title', 'Grant User Access'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    
    <!-- Page Header -->
    <div class="mb-6">
        <a href="<?php echo e(route('access.index')); ?>" class="text-indigo-600 hover:text-indigo-800 mb-2 inline-block">
            <i class="fas fa-arrow-left mr-2"></i>Back to Access Management
        </a>
        <h1 class="text-3xl font-bold text-gray-800">Grant User Access</h1>
        <p class="text-gray-600 mt-1">Configure system access with dynamic permissions</p>
    </div>
    
    <!-- Form Card -->
    <div class="bg-white rounded-xl shadow p-6">
        <form method="POST" action="<?php echo e(route('access.store')); ?>" id="accessForm" class="space-y-6">
            <?php echo csrf_field(); ?>
            
            <!-- Step 1: Basic Info -->
            <div class="border-b pb-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <span class="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center mr-3 text-sm">1</span>
                    Basic Information
                </h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <!-- Select User -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Select User <span class="text-red-500">*</span>
                        </label>
                        <select name="user_id" required
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                            <option value="">-- Choose User --</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->iduser); ?>" <?php echo e(old('user_id') == $user->iduser ? 'selected' : ''); ?>>
                                <?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?> (<?php echo e($user->username); ?>)
                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <!-- Select Role -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Global Role <span class="text-red-500">*</span>
                        </label>
                        <select name="role_id" required
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                            <option value="">-- Choose Role --</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>" <?php echo e(old('role_id') == $role->id ? 'selected' : ''); ?>>
                                <?php echo e($role->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <p class="text-xs text-gray-500 mt-1">General role across all systems</p>
                    </div>
                </div>
            </div>
            
            <!-- Step 2: System Selection -->
            <div class="border-b pb-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <span class="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center mr-3 text-sm">2</span>
                    Select System
                </h3>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        System <span class="text-red-500">*</span>
                    </label>
                    <select id="systemSelector" name="system_id" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                        <option value="">-- Choose System --</option>
                        <?php $__currentLoopData = $systems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $system): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($system->id); ?>" <?php echo e(old('system_id') == $system->id ? 'selected' : ''); ?>>
                            <?php echo e($system->system_name); ?> (<?php echo e($system->system_code); ?>)
                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['system_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <p class="text-xs text-gray-500 mt-1">
                        <i class="fas fa-magic mr-1"></i>Permission form will adjust based on selected system
                    </p>
                </div>
            </div>
            
            <!-- Step 3: Dynamic System-Specific Permissions -->
            <div id="dynamicPermissions" class="hidden">
                <div class="border-b pb-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                        <span class="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center mr-3 text-sm">3</span>
                        <span id="systemName">System</span> Permissions
                    </h3>
                    
                    <!-- Info Alert -->
                    <div class="bg-blue-50 border-l-4 border-blue-400 p-4 mb-6">
                        <div class="flex">
                            <i class="fas fa-info-circle text-blue-400 text-xl mr-3 mt-0.5"></i>
                            <div class="text-sm text-blue-800">
                                <p class="font-medium mb-1">Dynamic Permissions</p>
                                <p>These permissions are specific to <strong id="systemNameInfo">this system</strong>. 
                                   Fill according to user's role and responsibilities.</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Dynamic Fields Container -->
                    <div id="dynamicFields" class="grid grid-cols-1 md:grid-cols-2 gap-4"></div>
                </div>
            </div>
            
            <!-- Expiry Date -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Access Expires At <span class="text-gray-500 text-xs">(Optional - leave blank for permanent)</span>
                </label>
                <input type="date" name="expires_at" value="<?php echo e(old('expires_at')); ?>"
                       min="<?php echo e(date('Y-m-d', strtotime('+1 day'))); ?>"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                <?php $__errorArgs = ['expires_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <!-- Submit Buttons -->
            <div class="flex items-center justify-end space-x-3 pt-4">
                <a href="<?php echo e(route('access.index')); ?>" 
                   class="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                    Cancel
                </a>
                <button type="submit" 
                        class="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                    <i class="fas fa-key mr-2"></i>Grant Access
                </button>
            </div>
        </form>
    </div>
    
</div>

<!-- JavaScript for Dynamic Form -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const systemSelector = document.getElementById('systemSelector');
    const dynamicSection = document.getElementById('dynamicPermissions');
    const fieldsContainer = document.getElementById('dynamicFields');
    const systemNameSpan = document.getElementById('systemName');
    const systemNameInfo = document.getElementById('systemNameInfo');
    
    // System selector change handler
    systemSelector.addEventListener('change', async function() {
        const systemId = this.value;
        
        if (!systemId) {
            dynamicSection.classList.add('hidden');
            return;
        }
        
        try {
            // Show loading
            fieldsContainer.innerHTML = '<div class="col-span-2 text-center py-8"><i class="fas fa-spinner fa-spin text-3xl text-indigo-600"></i><p class="mt-2 text-gray-600">Loading permission template...</p></div>';
            dynamicSection.classList.remove('hidden');
            
            console.log('Fetching template for system ID:', systemId);
            
            // ✅ FIX: Gunakan URL helper Laravel untuk handle base path /ums
            const url = `<?php echo e(url('access/system-template')); ?>/${systemId}`;
            console.log('Full URL:', url);
            
            // Fetch template from server
            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            });
            
            console.log('Response status:', response.status);
            console.log('Response URL:', response.url);
            
            if (!response.ok) {
                const errorText = await response.text();
                console.error('HTTP Error:', response.status, errorText);
                throw new Error(`HTTP ${response.status}: ${response.statusText || errorText}`);
            }
            
            const data = await response.json();
            console.log('Response data:', data);
            
            if (!data.success) {
                throw new Error(data.message || 'Failed to load system template');
            }
            
            // Update system name
            systemNameSpan.textContent = data.system.name;
            systemNameInfo.textContent = data.system.name;
            
            // Clear previous fields
            fieldsContainer.innerHTML = '';
            
            // ✅ VALIDASI: Pastikan template dan fields ada
            if (!data.template) {
                throw new Error('Template is missing from response');
            }
            
            if (!data.template.fields || !Array.isArray(data.template.fields)) {
                throw new Error('Template fields is missing or invalid');
            }
            
            if (data.template.fields.length === 0) {
                fieldsContainer.innerHTML = '<div class="col-span-2 text-center py-4 text-gray-500">No permission fields configured for this system</div>';
            } else {
                // Generate fields
                data.template.fields.forEach(field => {
                    console.log('Generating field:', field);
                    const fieldHtml = generateField(field);
                    fieldsContainer.innerHTML += fieldHtml;
                });
            }
            
            // Show dynamic section
            dynamicSection.classList.remove('hidden');
            
            // Smooth scroll
            setTimeout(() => {
                dynamicSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }, 100);
            
        } catch (error) {
            console.error('Error loading template:', error);
            
            // Show error in UI
            fieldsContainer.innerHTML = `
                <div class="col-span-2">
                    <div class="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
                        <i class="fas fa-exclamation-circle text-red-500 text-3xl mb-3"></i>
                        <h4 class="text-red-700 font-bold text-lg mb-2">Error Loading Permission Template</h4>
                        <p class="text-red-600 mb-4">${error.message}</p>
                        <button onclick="location.reload()" class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700">
                            <i class="fas fa-redo mr-2"></i>Reload Page
                        </button>
                    </div>
                </div>
            `;
        }
    });
    
    // ✅ Field generator function
    function generateField(field) {
        const nameAttr = `metadata[${field.name}]`;
        const required = field.required ? 'required' : '';
        const requiredStar = field.required ? '<span class="text-red-500">*</span>' : '';
        
        switch (field.type) {
            case 'text':
                return `
                    <div class="form-group">
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            ${field.label} ${requiredStar}
                        </label>
                        <input type="text" name="${nameAttr}" 
                               placeholder="${field.placeholder || ''}" 
                               ${required}
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                        ${field.helpText ? `<p class="text-xs text-gray-500 mt-1">${field.helpText}</p>` : ''}
                    </div>
                `;
                
            case 'number':
                return `
                    <div class="form-group">
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            ${field.label} ${requiredStar}
                        </label>
                        <input type="number" name="${nameAttr}" 
                               value="${field.default || ''}"
                               min="${field.min || ''}" 
                               max="${field.max || ''}"
                               ${required}
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                        ${field.helpText ? `<p class="text-xs text-gray-500 mt-1">${field.helpText}</p>` : ''}
                    </div>
                `;
                
            case 'select':
                let options = '';
                if (Array.isArray(field.options)) {
                    options = field.options.map(opt => {
                        if (typeof opt === 'string') {
                            return `<option value="${opt}">${opt}</option>`;
                        } else {
                            return `<option value="${opt.value}">${opt.label}</option>`;
                        }
                    }).join('');
                }
                return `
                    <div class="form-group">
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            ${field.label} ${requiredStar}
                        </label>
                        <select name="${nameAttr}" ${required} 
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                            <option value="">-- Choose ${field.label} --</option>
                            ${options}
                        </select>
                        ${field.helpText ? `<p class="text-xs text-gray-500 mt-1">${field.helpText}</p>` : ''}
                    </div>
                `;
                
            case 'multiselect':
                let checkboxes = '';
                if (Array.isArray(field.options)) {
                    checkboxes = field.options.map(opt => `
                        <label class="flex items-center p-2 hover:bg-gray-50 rounded cursor-pointer">
                            <input type="checkbox" name="${nameAttr}[]" value="${opt}" 
                                   class="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500">
                            <span class="ml-3 text-sm text-gray-700">${opt}</span>
                        </label>
                    `).join('');
                }
                return `
                    <div class="form-group md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            ${field.label} ${requiredStar}
                        </label>
                        <div class="border border-gray-300 rounded-lg p-3 max-h-48 overflow-y-auto space-y-1">
                            ${checkboxes}
                        </div>
                        ${field.helpText ? `<p class="text-xs text-gray-500 mt-1">${field.helpText}</p>` : ''}
                    </div>
                `;
                
            case 'checkboxgroup':
                let checkboxGroup = '';
                if (Array.isArray(field.options)) {
                    checkboxGroup = field.options.map(opt => {
                        const checked = opt.default ? 'checked' : '';
                        return `
                            <label class="flex items-center p-2 hover:bg-gray-50 rounded cursor-pointer">
                                <input type="checkbox" name="${nameAttr}[${opt.value}]" 
                                       value="1" ${checked}
                                       class="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500">
                                <span class="ml-3 text-sm text-gray-700">${opt.label}</span>
                            </label>
                        `;
                    }).join('');
                }
                return `
                    <div class="form-group md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            ${field.label} ${requiredStar}
                        </label>
                        <div class="border border-gray-300 rounded-lg p-3 space-y-1">
                            ${checkboxGroup}
                        </div>
                        ${field.helpText ? `<p class="text-xs text-gray-500 mt-1">${field.helpText}</p>` : ''}
                    </div>
                `;
                
            case 'checkbox':
                const isChecked = field.default ? 'checked' : '';
                return `
                    <div class="form-group">
                        <label class="flex items-center space-x-2 cursor-pointer">
                            <input type="checkbox" name="${nameAttr}" value="1" ${isChecked}
                                   class="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500">
                            <span class="text-sm font-medium text-gray-700">${field.label}</span>
                        </label>
                        ${field.helpText ? `<p class="text-xs text-gray-500 mt-1 ml-6">${field.helpText}</p>` : ''}
                    </div>
                `;
                
            default:
                console.warn('Unknown field type:', field.type);
                return '';
        }
    }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/ums/resources/views/access/create.blade.php ENDPATH**/ ?>