<!-- resources/views/roles/permissions.blade.php -->



<?php $__env->startSection('title', 'Manage Permissions'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    
    <!-- Page Header -->
    <div class="mb-6">
        <a href="<?php echo e(route('roles.index')); ?>" class="text-indigo-600 hover:text-indigo-800 mb-2 inline-block">
            <i class="fas fa-arrow-left mr-2"></i>Back to Roles
        </a>
        <h1 class="text-3xl font-bold text-gray-800">Manage Permissions</h1>
        <p class="text-gray-600 mt-1">Assign permissions to: <strong><?php echo e($role->name); ?></strong></p>
    </div>
    
    <!-- Form Card -->
    <div class="bg-white rounded-xl shadow p-6">
        <form method="POST" action="<?php echo e(route('roles.permissions.update', $role->id)); ?>">
            <?php echo csrf_field(); ?>
            
            <!-- Permissions Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <?php $__currentLoopData = $allPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="flex items-center p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition">
                    <input type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>"
                           <?php echo e($role->permissions->contains($permission->id) ? 'checked' : ''); ?>

                           class="w-5 h-5 text-indigo-600 rounded focus:ring-2 focus:ring-indigo-500">
                    <div class="ml-3">
                        <p class="font-medium text-gray-800"><?php echo e(ucwords(str_replace('_', ' ', $permission->name))); ?></p>
                        <p class="text-sm text-gray-600"><?php echo e($permission->description); ?></p>
                    </div>
                </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <!-- Quick Actions -->
            <div class="mb-6 p-4 bg-gray-50 rounded-lg">
                <p class="text-sm font-medium text-gray-700 mb-2">Quick Actions:</p>
                <div class="flex space-x-2">
                    <button type="button" onclick="selectAll()" 
                            class="px-4 py-2 bg-indigo-100 text-indigo-700 rounded text-sm hover:bg-indigo-200">
                        <i class="fas fa-check-double mr-1"></i>Select All
                    </button>
                    <button type="button" onclick="deselectAll()" 
                            class="px-4 py-2 bg-gray-200 text-gray-700 rounded text-sm hover:bg-gray-300">
                        <i class="fas fa-times mr-1"></i>Deselect All
                    </button>
                </div>
            </div>
            
            <!-- Submit Buttons -->
            <div class="flex items-center justify-end space-x-3 pt-4 border-t">
                <a href="<?php echo e(route('roles.index')); ?>" 
                   class="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                    Cancel
                </a>
                <button type="submit" 
                        class="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                    <i class="fas fa-save mr-2"></i>Save Permissions
                </button>
            </div>
        </form>
    </div>
    
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function selectAll() {
    document.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = true);
}

function deselectAll() {
    document.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/ums/resources/views/roles/permissions.blade.php ENDPATH**/ ?>