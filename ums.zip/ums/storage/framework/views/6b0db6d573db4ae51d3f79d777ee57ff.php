<!-- resources/views/groups/members.blade.php -->



<?php $__env->startSection('title', 'Group Members'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    
    <!-- Page Header -->
    <div class="flex flex-col md:flex-row md:justify-between md:items-start space-y-4 md:space-y-0">
        <div>
            <a href="<?php echo e(route('groups.index', ['system_id' => $system->id])); ?>" 
               class="text-purple-600 hover:text-purple-800 mb-2 inline-flex items-center text-sm">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                Back to Groups
            </a>
            <h1 class="text-3xl font-bold text-gray-800 flex items-center">
                <div class="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mr-3 shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                </div>
                Members of "<?php echo e($groupName); ?>"
            </h1>
            <p class="text-gray-600 mt-2 ml-13">
                <span class="font-medium"><?php echo e($system->system_name); ?></span> • 
                <span class="px-2 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">
                    <?php echo e($members->count()); ?> <?php echo e(Str::plural('Member', $members->count())); ?>

                </span>
            </p>
        </div>
        
        <div class="flex space-x-3">
            <a href="<?php echo e(route('groups.edit', ['system_id' => $system->id, 'index' => request('index')])); ?>" 
               class="px-4 py-2 bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200 transition flex items-center text-sm">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
                Edit Group
            </a>
        </div>
    </div>
    
    <!-- Group Info Card -->
    <div class="glass-effect rounded-2xl shadow-lg p-6 border border-purple-200">
        <div class="flex items-start">
            <div class="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-500 rounded-xl flex items-center justify-center mr-4 shadow-md">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                </svg>
            </div>
            <div class="flex-1">
                <h3 class="text-xl font-bold text-gray-800 mb-1"><?php echo e($groupName); ?></h3>
                <p class="text-gray-600 mb-3"><?php echo e($group['description'] ?? 'No description provided'); ?></p>
                <div class="flex flex-wrap gap-2 text-xs text-gray-500">
                    <?php if(isset($group['created_at'])): ?>
                    <span class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        Created <?php echo e(\Carbon\Carbon::parse($group['created_at'])->format('d M Y')); ?>

                    </span>
                    <?php endif; ?>
                    <?php if(isset($group['created_by'])): ?>
                    <span class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                        by <?php echo e($group['created_by']); ?>

                    </span>
                    <?php endif; ?>
                    <?php if(isset($group['updated_at'])): ?>
                    <span class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                        </svg>
                        Updated <?php echo e(\Carbon\Carbon::parse($group['updated_at'])->format('d M Y')); ?>

                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Members Table -->
    <div class="glass-effect rounded-2xl shadow-lg border border-purple-200 overflow-hidden">
        <div class="bg-gradient-to-r from-purple-50 to-indigo-50 px-6 py-4 border-b border-purple-200">
            <h2 class="text-lg font-bold text-gray-800 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
                Member List
            </h2>
        </div>
        
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50 border-b-2 border-purple-200">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">User</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Email</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Role</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Section/State</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Other Groups</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $access): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-purple-50 transition">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <div class="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-500 rounded-xl flex items-center justify-center mr-3 shadow-sm">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                    </svg>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-gray-900"><?php echo e($access->user->firstname); ?> <?php echo e($access->user->lastname); ?></p>
                                    <p class="text-xs text-gray-500"><?php echo e($access->user->username); ?></p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            <?php echo e($access->user->email_corp ?? '-'); ?>

                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-3 py-1 text-xs font-medium rounded-full bg-purple-100 text-purple-800">
                                <?php echo e($access->role->name); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4">
                            <div class="space-y-1">
                                <div class="text-xs text-gray-700"><?php echo e($access->getSection()); ?></div>
                                <?php
                                    $state = $access->getState();
                                    $stateColors = [
                                        'Approver' => 'bg-green-100 text-green-800',
                                        'Originator' => 'bg-blue-100 text-blue-800',
                                        'Admin' => 'bg-red-100 text-red-800',
                                    ];
                                    $stateColor = $stateColors[$state] ?? 'bg-gray-100 text-gray-800';
                                ?>
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium <?php echo e($stateColor); ?>">
                                    <?php echo e($state); ?>

                                </span>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <?php 
                                $allGroups = $access->getGroups();
                                $otherGroups = array_filter($allGroups, fn($g) => $g !== $groupName);
                            ?>
                            <?php if(count($otherGroups) > 0): ?>
                                <div class="flex flex-wrap gap-1">
                                    <?php $__currentLoopData = array_slice($otherGroups, 0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-700"><?php echo e($otherGroup); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($otherGroups) > 2): ?>
                                    <span class="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-600">+<?php echo e(count($otherGroups) - 2); ?></span>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <span class="text-xs text-gray-400 italic">None</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <a href="<?php echo e(route('access.edit', $access->id)); ?>" 
                               class="text-blue-600 hover:text-blue-900 text-sm font-medium">
                                Edit Access →
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="px-6 py-12 text-center text-gray-500">
                            <div class="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                                </svg>
                            </div>
                            <p class="text-lg font-medium text-gray-600">No members in this group</p>
                            <p class="text-sm text-gray-500 mt-1">Assign users to this group from the Access Management page</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/ums/resources/views/groups/members.blade.php ENDPATH**/ ?>