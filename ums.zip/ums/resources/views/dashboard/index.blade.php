<!-- resources/views/dashboard/index.blade.php -->

@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<div class="space-y-6">
    
    <!-- Page Header -->
    <div class="flex flex-col md:flex-row md:justify-between md:items-center space-y-4 md:space-y-0">
        <div>
            <h1 class="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
                Welcome back, <span class="text-blue-600">{{ $user->firstname }}</span>! 👋
            </h1>
            <p class="text-gray-600">Here's what's happening with your account today.</p>
        </div>
        <div class="flex items-center space-x-3 text-sm text-gray-600 glass-effect px-4 py-2 rounded-xl border border-blue-200">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>{{ now()->format('d M Y, H:i') }}</span>
        </div>
    </div>
    
    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        
        <!-- Total Users -->
        <div class="glass-effect rounded-2xl shadow-lg p-6 border border-blue-200 hover:shadow-xl transition group">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-500 rounded-xl flex items-center justify-center shadow-md group-hover:scale-110 transition">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                </div>
                <span class="px-3 py-1 bg-blue-50 text-blue-600 text-xs font-semibold rounded-full">+12%</span>
            </div>
            <p class="text-gray-600 text-sm mb-1">Total Users</p>
            <h3 class="text-3xl font-bold text-gray-800">{{ number_format($stats['total_users']) }}</h3>
        </div>
        
        <!-- Total Systems -->
        <div class="glass-effect rounded-2xl shadow-lg p-6 border border-blue-200 hover:shadow-xl transition group">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-gradient-to-br from-green-400 to-green-500 rounded-xl flex items-center justify-center shadow-md group-hover:scale-110 transition">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" />
                    </svg>
                </div>
                <span class="px-3 py-1 bg-green-50 text-green-600 text-xs font-semibold rounded-full">Active</span>
            </div>
            <p class="text-gray-600 text-sm mb-1">Total Systems</p>
            <h3 class="text-3xl font-bold text-gray-800">{{ number_format($stats['total_systems']) }}</h3>
        </div>
        
        <!-- Active Sessions -->
        <div class="glass-effect rounded-2xl shadow-lg p-6 border border-blue-200 hover:shadow-xl transition group">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-gradient-to-br from-purple-400 to-purple-500 rounded-xl flex items-center justify-center shadow-md group-hover:scale-110 transition">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                </div>
                <span class="px-3 py-1 bg-purple-50 text-purple-600 text-xs font-semibold rounded-full">Live</span>
            </div>
            <p class="text-gray-600 text-sm mb-1">Active Sessions</p>
            <h3 class="text-3xl font-bold text-gray-800">{{ number_format($stats['active_sessions']) }}</h3>
        </div>
        
        <!-- Today's Logins -->
        <div class="glass-effect rounded-2xl shadow-lg p-6 border border-blue-200 hover:shadow-xl transition group">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-gradient-to-br from-orange-400 to-orange-500 rounded-xl flex items-center justify-center shadow-md group-hover:scale-110 transition">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                    </svg>
                </div>
                <span class="px-3 py-1 bg-orange-50 text-orange-600 text-xs font-semibold rounded-full">Today</span>
            </div>
            <p class="text-gray-600 text-sm mb-1">Today's Logins</p>
            <h3 class="text-3xl font-bold text-gray-800">{{ number_format($stats['today_logins']) }}</h3>
        </div>
        
    </div>
    
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <!-- Your Systems Access -->
        <div class="glass-effect rounded-2xl shadow-lg p-6 border border-blue-200">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-bold text-gray-800 flex items-center">
                    <div class="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mr-3">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                        </svg>
                    </div>
                    Your System Access
                </h2>
                <span class="px-3 py-1 bg-blue-50 text-blue-600 text-xs font-semibold rounded-full">
                    {{ $userSystems->count() }} Systems
                </span>
            </div>
            
            @if($userSystems->count() > 0)
            <div class="space-y-3">
                @foreach($userSystems as $access)
                <div class="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl hover:from-blue-100 hover:to-indigo-100 transition group border border-blue-200">
                    <div class="flex items-center space-x-3">
                        <div class="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-md group-hover:scale-110 transition">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                            </svg>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-800">{{ $access->system->system_name }}</p>
                            <div class="flex items-center space-x-2 mt-1">
                                <span class="px-2 py-0.5 bg-white text-blue-600 text-xs font-medium rounded-full border border-blue-200">
                                    {{ $access->role->name }}
                                </span>
                            </div>
                        </div>
                    </div>
                    <a href="{{ $access->system->system_url }}" target="_blank"
                       class="px-4 py-2 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl text-sm font-medium hover:from-blue-600 hover:to-blue-700 shadow-md hover:shadow-lg transition flex items-center space-x-2">
                        <span>Open</span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                        </svg>
                    </a>
                </div>
                @endforeach
            </div>
            @else
            <div class="text-center py-12">
                <div class="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-blue-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
                    </svg>
                </div>
                <p class="text-gray-600">No system access granted yet</p>
                <p class="text-sm text-gray-500 mt-1">Contact your administrator for access</p>
            </div>
            @endif
        </div>
        
        <!-- Recent Activity -->
        <div class="glass-effect rounded-2xl shadow-lg p-6 border border-blue-200">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-bold text-gray-800 flex items-center">
                    <div class="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mr-3">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>
                    Recent Activity
                </h2>
                <a href="{{ route('audit.index') }}" class="text-sm text-blue-600 hover:text-blue-700 font-medium">
                    View All →
                </a>
            </div>
            
            @if($recentActivity->count() > 0)
            <div class="space-y-3">
                @foreach($recentActivity as $log)
                <div class="flex items-start space-x-3 p-4 bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl hover:from-gray-100 hover:to-blue-100 transition border border-blue-100">
                    <div class="w-10 h-10 {{ $log->status == 'success' ? 'bg-gradient-to-br from-green-400 to-green-500' : 'bg-gradient-to-br from-red-400 to-red-500' }} rounded-xl flex items-center justify-center flex-shrink-0 shadow-md">
                        @if($log->status == 'success')
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                        </svg>
                        @else
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                        @endif
                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="text-sm font-semibold text-gray-800 truncate">{{ str_replace('_', ' ', ucwords($log->action)) }}</p>
                        <p class="text-xs text-gray-600 mt-1">{{ $log->created_at->diffForHumans() }}</p>
                    </div>
                    <span class="px-2 py-1 {{ $log->status == 'success' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600' }} text-xs font-medium rounded-full">
                        {{ ucfirst($log->status) }}
                    </span>
                </div>
                @endforeach
            </div>
            @else
            <div class="text-center py-12">
                <div class="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-blue-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <p class="text-gray-600">No recent activity</p>
                <p class="text-sm text-gray-500 mt-1">Your actions will appear here</p>
            </div>
            @endif
        </div>
        
    </div>
    
</div>
@endsection