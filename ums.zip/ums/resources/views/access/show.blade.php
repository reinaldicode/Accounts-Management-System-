<!-- resources/views/access/show.blade.php -->

@extends('layouts.app')

@section('title', 'Access Details')

@section('content')
<div class="max-w-5xl mx-auto">
    
    <!-- Page Header -->
    <div class="mb-6">
        <a href="{{ route('access.index') }}" class="text-indigo-600 hover:text-indigo-800 mb-2 inline-block">
            <i class="fas fa-arrow-left mr-2"></i>Back to Access Management
        </a>
        <h1 class="text-3xl font-bold text-gray-800">Access Details</h1>
        <p class="text-gray-600 mt-1">Complete access information and permissions</p>
    </div>
    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Main Info Card -->
        <div class="lg:col-span-2 space-y-6">
            
            <!-- User & System Info -->
            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">
                    <i class="fas fa-info-circle text-indigo-600 mr-2"></i>Access Information
                </h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- User Info -->
                    <div>
                        <label class="block text-sm font-medium text-gray-500 mb-2">User</label>
                        <div class="flex items-center space-x-3">
                            <div class="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-user text-indigo-600 text-xl"></i>
                            </div>
                            <div>
                                <p class="text-lg font-bold text-gray-900">
                                    {{ $access->user->firstname }} {{ $access->user->lastname }}
                                </p>
                                <p class="text-sm text-gray-600">
                                    {{ $access->user->username }} ({{ $access->user->empid }})
                                </p>
                                <p class="text-sm text-gray-600">{{ $access->user->email_corp }}</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- System Info -->
                    <div>
                        <label class="block text-sm font-medium text-gray-500 mb-2">System</label>
                        <div class="flex items-center space-x-3">
                            <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-cube text-green-600 text-xl"></i>
                            </div>
                            <div>
                                <p class="text-lg font-bold text-gray-900">{{ $access->system->system_name }}</p>
                                <p class="text-sm text-gray-600">Code: {{ $access->system->system_code }}</p>
                                <a href="{{ $access->system->system_url }}" target="_blank" 
                                   class="text-sm text-indigo-600 hover:underline">
                                    {{ $access->system->system_url }} <i class="fas fa-external-link-alt text-xs"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Permissions Details -->
            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">
                    <i class="fas fa-shield-alt text-green-600 mr-2"></i>Permission Details
                </h2>
                
                <div class="space-y-4">
                    <!-- Global Role -->
                    <div class="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Global Role</label>
                            <p class="text-lg font-bold text-purple-800">
                                <i class="fas fa-user-tag mr-2"></i>{{ $access->role->name }}
                            </p>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <!-- Section -->
                        <div class="p-4 bg-blue-50 rounded-lg">
                            <label class="block text-xs font-medium text-gray-600 mb-1">Section</label>
                            <p class="text-sm font-bold text-blue-800">
                                <i class="fas fa-layer-group mr-1"></i>{{ $access->getSection() }}
                            </p>
                        </div>
                        
                        <!-- Department -->
                        <div class="p-4 bg-indigo-50 rounded-lg">
                            <label class="block text-xs font-medium text-gray-600 mb-1">Department</label>
                            <p class="text-sm font-bold text-indigo-800">
                                <i class="fas fa-building mr-1"></i>{{ $access->getDepartment() ?? '-' }}
                            </p>
                        </div>
                        
                        <!-- State -->
                        <div class="p-4 bg-green-50 rounded-lg">
                            <label class="block text-xs font-medium text-gray-600 mb-1">State</label>
                            <p class="text-sm font-bold text-green-800">
                                <i class="fas fa-shield-alt mr-1"></i>{{ $access->getState() }}
                            </p>
                        </div>
                        
                        <!-- Level -->
                        <div class="p-4 bg-orange-50 rounded-lg">
                            <label class="block text-xs font-medium text-gray-600 mb-1">Access Level</label>
                            <p class="text-sm font-bold text-orange-800">
                                <i class="fas fa-signal mr-1"></i>Level {{ $access->getLevel() }}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Groups -->
            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">
                    <i class="fas fa-users text-purple-600 mr-2"></i>Group Memberships
                </h2>
                
                @php
                    $groups = $access->getGroups();
                @endphp
                
                @if(!empty($groups))
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                    @foreach($groups as $group)
                    <div class="flex items-center p-3 bg-purple-50 border border-purple-200 rounded-lg">
                        <i class="fas fa-users text-purple-600 mr-3"></i>
                        <span class="text-sm font-medium text-gray-800">{{ $group }}</span>
                    </div>
                    @endforeach
                </div>
                @else
                <p class="text-gray-500 text-center py-4">
                    <i class="fas fa-info-circle mr-2"></i>No group memberships
                </p>
                @endif
            </div>
            
        </div>
        
        <!-- Sidebar -->
        <div class="space-y-6">
            
            <!-- Status Card -->
            <div class="bg-white rounded-xl shadow p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4">Status</h3>
                
                <div class="space-y-3">
                    <!-- Active Status -->
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">Active</span>
                        @if($access->isActive())
                        <span class="px-3 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                            <i class="fas fa-check-circle mr-1"></i>Yes
                        </span>
                        @else
                        <span class="px-3 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800">
                            <i class="fas fa-times-circle mr-1"></i>No
                        </span>
                        @endif
                    </div>
                    
                    <!-- Granted Date -->
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">Granted</span>
                        <span class="text-sm font-medium text-gray-800">
                            {{ $access->granted_at->format('d M Y') }}
                        </span>
                    </div>
                    
                    <!-- Granted By -->
                    @if($access->grantedBy)
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">Granted By</span>
                        <span class="text-sm font-medium text-gray-800">
                            {{ $access->grantedBy->firstname }}
                        </span>
                    </div>
                    @endif
                    
                    <!-- Expires At -->
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">Expires</span>
                        @if($access->expires_at)
                        <span class="text-sm font-medium {{ $access->hasExpired() ? 'text-red-600' : 'text-gray-800' }}">
                            {{ $access->expires_at->format('d M Y') }}
                        </span>
                        @else
                        <span class="text-sm font-medium text-gray-800">Never</span>
                        @endif
                    </div>
                </div>
            </div>
            
            <!-- Actions Card -->
            <div class="bg-white rounded-xl shadow p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4">Actions</h3>
                
                <div class="space-y-2">
                    <a href="{{ route('access.edit', $access->id) }}" 
                       class="block w-full px-4 py-2 bg-blue-600 text-white text-center rounded-lg hover:bg-blue-700">
                        <i class="fas fa-edit mr-2"></i>Edit Access
                    </a>
                    
                    <form method="POST" action="{{ route('access.toggle', $access->id) }}" class="block">
                        @csrf
                        <button type="submit" 
                                class="w-full px-4 py-2 {{ $access->is_active ? 'bg-orange-600 hover:bg-orange-700' : 'bg-green-600 hover:bg-green-700' }} text-white rounded-lg">
                            <i class="fas fa-power-off mr-2"></i>{{ $access->is_active ? 'Deactivate' : 'Activate' }}
                        </button>
                    </form>
                    
                    <form method="POST" action="{{ route('access.revoke', $access->id) }}" 
                          onsubmit="return confirm('Revoke this access? This cannot be undone.')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" 
                                class="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
                            <i class="fas fa-trash mr-2"></i>Revoke Access
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Access Summary -->
            <div class="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl shadow p-6 text-white">
                <h3 class="text-lg font-bold mb-3">
                    <i class="fas fa-chart-pie mr-2"></i>Access Summary
                </h3>
                <div class="space-y-2 text-sm">
                    <p><i class="fas fa-check-circle mr-2"></i>{{ $access->isApprover() ? 'Can Approve' : 'Cannot Approve' }}</p>
                    <p><i class="fas fa-edit mr-2"></i>{{ $access->isOriginator() ? 'Can Create' : 'Cannot Create' }}</p>
                    <p><i class="fas fa-users mr-2"></i>{{ count($access->getGroups()) }} Group{{ count($access->getGroups()) != 1 ? 's' : '' }}</p>
                </div>
            </div>
            
        </div>
        
    </div>
    
</div>
@endsection