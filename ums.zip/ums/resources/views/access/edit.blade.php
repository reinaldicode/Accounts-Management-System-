@extends('layouts.app')

@section('title', 'Edit User Access')

@section('content')
<div class="max-w-4xl mx-auto">
    
    <div class="mb-6">
        <a href="{{ route('access.index') }}" class="text-indigo-600 hover:text-indigo-800 mb-2 inline-flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Access Management
        </a>
        <h1 class="text-3xl font-bold text-gray-800 mt-2">Edit User Access</h1>
        <p class="text-gray-600 mt-1">
            Update access for: <strong>{{ $access->user->firstname }} {{ $access->user->lastname }}</strong>
            to <strong>{{ $access->system->system_name }}</strong>
        </p>
    </div>
    
    @if ($errors->any())
    <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
        <div class="flex">
            <div class="flex-shrink-0">
                <svg class="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                </svg>
            </div>
            <div class="ml-3">
                <h3 class="text-sm font-medium text-red-800">There were errors with your submission</h3>
                <ul class="mt-2 text-sm text-red-700 list-disc list-inside">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
    @endif
    
    <div class="bg-white rounded-xl shadow p-6">
        <form method="POST" action="{{ route('access.update', $access->id) }}" class="space-y-6">
            @csrf
            @method('PUT')
            
            <div class="border-b pb-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-indigo-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Access Information
                </h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="p-4 bg-gray-50 rounded-lg">
                        <label class="block text-sm font-medium text-gray-700 mb-1">User</label>
                        <p class="text-gray-900 font-medium">
                            {{ $access->user->firstname }} {{ $access->user->lastname }}
                            <span class="text-gray-500">({{ $access->user->username }})</span>
                        </p>
                    </div>
                    
                    <div class="p-4 bg-gray-50 rounded-lg">
                        <label class="block text-sm font-medium text-gray-700 mb-1">System</label>
                        <p class="text-gray-900 font-medium">
                            {{ $access->system->system_name }}
                            <span class="text-gray-500">({{ $access->system->system_code }})</span>
                        </p>
                    </div>
                </div>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Global Role <span class="text-red-500">*</span>
                </label>
                <select name="role_id" required
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                    @foreach($roles as $role)
                    <option value="{{ $role->id }}" {{ $access->role_id == $role->id ? 'selected' : '' }}>
                        {{ $role->name }}
                        @if($role->department || $role->section)
                        - {{ $role->department }} {{ $role->section }}
                        @endif
                    </option>
                    @endforeach
                </select>
                @error('role_id')
                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>
            
            <div class="border-b pb-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-green-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                    Application Permissions
                </h3>
                
                @php
                    // Ambil template dari System
                    $template = $access->system->permission_template;
                    if(is_string($template)) {
                        $template = json_decode($template, true);
                    }
                    $fields = $template['fields'] ?? [];
                    
                    // Fallback jika tidak ada template, pakai standar (Section, State, Level)
                    if(empty($fields)) {
                        $fields = [
                            ['name' => 'section', 'label' => 'Section', 'type' => 'text', 'required' => true],
                            ['name' => 'state', 'label' => 'State', 'type' => 'select', 'required' => true, 'options' => [['value'=>'Admin','label'=>'Admin'], ['value'=>'Approver','label'=>'Approver'], ['value'=>'Originator','label'=>'Originator'], ['value'=>'Viewer','label'=>'Viewer']]],
                            ['name' => 'level', 'label' => 'Level (0-10)', 'type' => 'number', 'min' => 0, 'max' => 10],
                        ];
                    }
                @endphp

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    @foreach($fields as $field)
                        @php
                            // Skip fields yang tipenya 'groups'/'multiselect' karena akan dirender terpisah di bawah
                            if(in_array($field['name'], ['groups', 'group_id'])) continue;
                            if(isset($field['type']) && in_array($field['type'], ['multiselect', 'checkboxgroup'])) continue;

                            // Ambil value saat ini dari access_metadata
                            $currentValue = $access->access_metadata[$field['name']] ?? ($field['default'] ?? '');
                            $isRequired = isset($field['required']) && $field['required'];
                        @endphp

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                {{ $field['label'] }} {!! $isRequired ? '<span class="text-red-500">*</span>' : '' !!}
                            </label>

                            @if($field['type'] === 'select')
                                <select name="metadata[{{ $field['name'] }}]" {{ $isRequired ? 'required' : '' }}
                                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500">
                                    <option value="">-- Select {{ $field['label'] }} --</option>
                                    @foreach($field['options'] as $opt)
                                        @php
                                            $val = is_array($opt) ? $opt['value'] : $opt;
                                            $lab = is_array($opt) ? $opt['label'] : $opt;
                                        @endphp
                                        <option value="{{ $val }}" {{ $currentValue == $val ? 'selected' : '' }}>
                                            {{ $lab }}
                                        </option>
                                    @endforeach
                                </select>

                            @elseif($field['type'] === 'number')
                                <input type="number" name="metadata[{{ $field['name'] }}]" 
                                       value="{{ $currentValue }}"
                                       min="{{ $field['min'] ?? '' }}" max="{{ $field['max'] ?? '' }}"
                                       {{ $isRequired ? 'required' : '' }}
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500">

                            @else
                                <input type="text" name="metadata[{{ $field['name'] }}]" 
                                       value="{{ $currentValue }}"
                                       {{ $isRequired ? 'required' : '' }}
                                       placeholder="{{ $field['placeholder'] ?? '' }}"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500">
                            @endif
                        </div>
                    @endforeach
                </div>
            </div>
            
            @php
                // Cari apakah ada field groups/multiselect di template
                $groupField = null;
                foreach($fields as $f) {
                    if($f['name'] === 'groups' || (isset($f['type']) && in_array($f['type'], ['multiselect', 'checkboxgroup']))) {
                        $groupField = $f;
                        break;
                    }
                }
                
                // Gunakan availableGroups dari Controller jika ada, atau options dari template
                $groupOptions = !empty($availableGroups) ? $availableGroups : ($groupField['options'] ?? []);
                $currentGroups = $access->getGroups(); // Helper dari Model
            @endphp

            @if(!empty($groupOptions))
            <div class="border-b pb-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-purple-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                    {{ $groupField['label'] ?? 'Group Memberships' }}
                </h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    @foreach($groupOptions as $group)
                        @php
                           // Handle jika $group bentuknya array ['value'=>..., 'label'=>...]
                           $gVal = is_array($group) ? ($group['name'] ?? $group['value']) : $group;
                           $gLabel = is_array($group) ? ($group['name'] ?? $group['label']) : $group;
                        @endphp
                    <label class="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition">
                        <input type="checkbox" name="metadata[groups][]" value="{{ $gVal }}"
                               {{ in_array($gVal, $currentGroups) ? 'checked' : '' }}
                               class="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500">
                        <span class="ml-3 text-sm text-gray-700 flex items-center">
                            {{ $gLabel }}
                        </span>
                    </label>
                    @endforeach
                </div>
            </div>
            @endif
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    Access Expires At
                </label>
                <input type="date" name="expires_at" 
                       value="{{ old('expires_at', $access->expires_at?->format('Y-m-d')) }}"
                       min="{{ date('Y-m-d', strtotime('+1 day')) }}"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500">
                <p class="mt-1 text-xs text-gray-500">Leave blank for permanent access</p>
            </div>
            
            <div class="flex items-center justify-end space-x-3 pt-4 border-t">
                <a href="{{ route('access.index') }}" 
                   class="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition flex items-center">
                    Cancel
                </a>
                <button type="submit" 
                        class="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition flex items-center">
                    Update Access
                </button>
            </div>
        </form>
    </div>
</div>
@endsection