<!-- resources/views/groups/edit.blade.php -->

@extends('layouts.app')

@section('title', 'Edit Group')

@section('content')
<div class="max-w-2xl mx-auto">
    
    <!-- Page Header -->
    <div class="mb-6">
        <a href="{{ route('groups.index', ['system_id' => $system->id]) }}" 
           class="text-purple-600 hover:text-purple-800 mb-2 inline-flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Groups
        </a>
        <h1 class="text-3xl font-bold text-gray-800">Edit Group</h1>
        <p class="text-gray-600 mt-1">Update group information for <strong>{{ $system->system_name }}</strong></p>
    </div>
    
    <!-- Form Card -->
    <div class="glass-effect rounded-2xl shadow-lg p-6 border border-purple-200">
        <form method="POST" action="{{ route('groups.update') }}" class="space-y-6">
            @csrf
            <input type="hidden" name="system_id" value="{{ $system->id }}">
            <input type="hidden" name="index" value="{{ $group['index'] }}">
            
            <!-- Current Group Info -->
            <div class="bg-purple-50 border border-purple-200 rounded-xl p-4">
                <div class="flex items-center">
                    <div class="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center mr-3">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-purple-900">Currently Editing</p>
                        <p class="text-sm text-purple-700">{{ $group['name'] }}</p>
                    </div>
                </div>
            </div>
            
            <!-- Group Name -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Group Name <span class="text-red-500">*</span>
                </label>
                <input type="text" name="group_name" value="{{ old('group_name', $group['name']) }}" required
                       placeholder="e.g., ISO Audit Team, Document Control"
                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                @error('group_name')
                <p class="mt-1 text-sm text-red-600 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    {{ $message }}
                </p>
                @enderror
            </div>
            
            <!-- Description -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Description <span class="text-gray-500 text-xs">(Optional)</span>
                </label>
                <textarea name="description" rows="3" 
                          placeholder="Describe the purpose of this group..."
                          class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none">{{ old('description', $group['description'] ?? '') }}</textarea>
                @error('description')
                <p class="mt-1 text-sm text-red-600 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    {{ $message }}
                </p>
                @enderror
            </div>
            
            <!-- Warning Box -->
            <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded">
                <div class="flex">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400 mr-3 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <div class="text-sm text-yellow-800">
                        <p class="font-medium mb-1">Important Note</p>
                        <p>If you change the group name, all user assignments will be automatically updated.</p>
                    </div>
                </div>
            </div>
            
            <!-- Submit Buttons -->
            <div class="flex items-center justify-end space-x-3 pt-4 border-t">
                <a href="{{ route('groups.index', ['system_id' => $system->id]) }}" 
                   class="px-6 py-2.5 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition">
                    Cancel
                </a>
                <button type="submit" 
                        class="px-6 py-2.5 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-xl hover:from-purple-600 hover:to-purple-700 shadow-md hover:shadow-lg transition flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Update Group
                </button>
            </div>
        </form>
    </div>
    
</div>
@endsection