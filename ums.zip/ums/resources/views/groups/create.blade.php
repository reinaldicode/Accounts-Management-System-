<!-- resources/views/groups/create.blade.php -->

@extends('layouts.app')

@section('title', 'Add New Group')

@section('content')
<div class="max-w-2xl mx-auto">
    
    <!-- Page Header -->
    <div class="mb-6">
        <a href="{{ route('groups.index', ['system_id' => $system->id]) }}" 
           class="text-purple-600 hover:text-purple-800 mb-2 inline-flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Groups
        </a>
        <h1 class="text-3xl font-bold text-gray-800">Add New Group</h1>
        <p class="text-gray-600 mt-1">Create a new group for <strong>{{ $system->system_name }}</strong></p>
    </div>
    
    <!-- Form Card -->
    <div class="glass-effect rounded-2xl shadow-lg p-6 border border-purple-200">
        <form method="POST" action="{{ route('groups.store') }}" class="space-y-6">
            @csrf
            <input type="hidden" name="system_id" value="{{ $system->id }}">
            
            <!-- Group Name -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Group Name <span class="text-red-500">*</span>
                </label>
                <input type="text" name="group_name" value="{{ old('group_name') }}" required
                       placeholder="e.g., ISO Audit Team, Document Control, Safety Committee"
                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                @error('group_name')
                <p class="mt-1 text-sm text-red-600 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    {{ $message }}
                </p>
                @enderror
                <p class="text-xs text-gray-500 mt-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 inline mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Use descriptive names that reflect the group's purpose
                </p>
            </div>
            
            <!-- Description -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Description <span class="text-gray-500 text-xs">(Optional)</span>
                </label>
                <textarea name="description" rows="3" 
                          placeholder="Describe the purpose and responsibilities of this group..."
                          class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none">{{ old('description') }}</textarea>
                @error('description')
                <p class="mt-1 text-sm text-red-600 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    {{ $message }}
                </p>
                @enderror
            </div>
            
            <!-- Info Box -->
            <div class="bg-blue-50 border-l-4 border-blue-400 p-4 rounded">
                <div class="flex">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-blue-400 mr-3 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <div class="text-sm text-blue-800">
                        <p class="font-medium mb-1">About Groups</p>
                        <ul class="list-disc list-inside space-y-1 text-blue-700">
                            <li>Groups help organize users by function or responsibility</li>
                            <li>Users can be assigned to multiple groups</li>
                            <li>Groups can be used for permission targeting in {{ $system->system_name }}</li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Submit Buttons -->
            <div class="flex items-center justify-end space-x-3 pt-4 border-t">
                <a href="{{ route('groups.index', ['system_id' => $system->id]) }}" 
                   class="px-6 py-2.5 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition">
                    Cancel
                </a>
                <button type="submit" 
                        class="px-6 py-2.5 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-xl hover:from-purple-600 hover:to-purple-700 shadow-md hover:shadow-lg transition flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                    </svg>
                    Create Group
                </button>
            </div>
        </form>
    </div>
    
</div>
@endsection